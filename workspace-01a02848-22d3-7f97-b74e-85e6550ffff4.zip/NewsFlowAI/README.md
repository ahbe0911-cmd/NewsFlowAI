# 📰 NewsFlow AI — نیوزفلو هوش مصنوعی

> **شبکه اجتماعی خبری هوشمند** — نه RSS Reader، نه خبرخوان؛ یک پلتفرم محتوایی مدرن با فید اجتماعی،
> دستیار AI روی‌گوشی، خلاصه روزانه، واکنش‌ها و هاب کانال‌های تلگرام — **تمام‌فارسی و RTL**.

---

## ✨ امکانات کلیدی

| بخش | توضیح |
|---|---|
| 🏠 Home Feed | فید اجتماعی با کارت‌های گلس، ردیف کانال‌ها (استایل استوری)، Pull-to-Refresh، ورود نرم کارت‌ها |
| 🧠 AI Engine (On-Device) | خلاصه‌سازی استخراجی فارسی + نکات کلیدی + نمره اهمیت (فوری/مهم) + اخبار مرتبط + مقایسه دو خبر + خلاصه روزانه + یافتن «پیوند پنهان‌ها» |
| 🤖 AI Assistant | چت با اقدام‌های سریع: خلاصه روزانه، فوری‌ها، مقایسه، پیوندها، پیشنهاد شخصی |
| 📡 Channel Hub | افزودن کانال عمومی تلگرام (@username یا t.me/link)، سوییچ دنبال‌کردن، حذف، دسته‌بندی، پیشنهاد محبوب‌ها |
| 🔍 Discover | جست‌وجو، هشتگ‌های ترند (استخراج کلمات کلیدی روز)، کاروسل «پیشنهاد برای شما»، رتبه‌بندی داغ‌ترین‌ها |
| 👤 Profile | کاور گرادیانی، آمار خوانش، علایق استنباطی از رفتار، تاریخچه مطالعه |
| 🔔 اعلان‌ها | کانال‌های جداگانه: فوری / خلاصه روزانه ساعت ۱۷:۰۰ / پیشنهاد هوشمند + FCM |
| ⚙ Settings | تم تاریک/روشن/خودکار، اندازه فونت (فونت وزیر)، سوئیچ‌های AI، علایق، حریم خصوصی On-Device |

## 🏗 معماری (Clean + MVVM + Hilt)

```
ir.newsflow.ai
├── NewsFlowApp.kt              # @HiltAndroidApp + WorkManager Config
├── MainActivity.kt             # Splash + EdgeToEdge + Theme
├── core/                       # لایه دامنه (بدون وابستگی اندرویدی به UI)
│   ├── Models.kt               # Post, Channel, Importance, Reaction …
│   └── repo/Contracts.kt       # FeedRepository | ChannelRepository | ProfileRepository
├── data/
│   ├── local/AppDatabase.kt    # Room: channels, posts, saved, reactions, read_history
│   ├── repo/NewsRepositoryImpl.kt  # پیاده‌سازی + Seed + سینک شبیه‌سازی
│   ├── ai/AiEngine.kt          # NLP فارسی روی‌گوشی (تست‌پذیر, pure)
│   ├── seed/SeedData.kt        # محتوای فارسی نمونه (آفلاین-دوست)
│   └── Prefs.kt                # DataStore تنظیمات
├── di/AppModule.kt             # Hilt modules (Provides/Binds)
├── notif/Notifications.kt      # NotificationHelper + DailyDigestWorker(17:00) + InstantCheckWorker + FCM
└── ui/
    ├── theme/Theme.kt          # Material 3 + گرادیان برند + فونت وزیر + timeAgo فارسی
    ├── components/             # NewsCard, AiSummaryBox, ImportanceMeter, ReactionBar, GlassCard …
    ├── nav/Nav.kt              # NavHost + Bottom Navigation
    └── screens/                # Splash, Login, Home, Discover, ChannelsHub, Detail, Saved, Profile, Settings, Assistant
```

**تکنولوژی‌ها:** Kotlin 2.0 · Jetpack Compose (BOM 2024.09) · Material 3 · Hilt · Room · DataStore · WorkManager · FCM · Coil · Coroutines/Flow

---

## 🔧 ساخت APK — بدون Android Studio (فقط خط فرمان)

### ۱) پیش‌نیاز
- **JDK 17** («تنها چیزی که لازم است» — نصب کنید یا از portable استفاده کنید)
- اتصال اینترنت (پربار دانلود اولیه Gradle و وابستگی‌ها)

### ۲) نصب Android SDK با خط فرمان
```bash
# دانلود command line tools از سایت گوگل (https://developer.android.com/studio#command-tools)
mkdir -p ~/Android/Sdk/cmdline-tools && cd ~/Android/Sdk/cmdline-tools
# فایل دانلودشده را به شکل latest/ از حالت فشرده خارج کنید
export ANDROID_HOME=~/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

sdkmanager --licenses            # y برای همه
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

### ۳) Build
```bash
cd NewsFlowAI
echo "sdk.dir=$HOME/Android/Sdk" > local.properties
./gradlew clean
./gradlew assembleDebug          # → app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease        # نسخه Release (مینیفای + shrink)
```

### ۴) امضا برای انتشار
```bash
keytool -genkey -v -keystore newsflow.jks -alias newsflow -keyalg RSA -keysize 2048 -validity 10000
# در gradle.properties اضافه کنید:
# NEWSFLOW_STORE_FILE=... ; NEWSFLOW_STORE_PASSWORD=... ; NEWSFLOW_KEY_ALIAS=newsflow ; NEWSFLOW_KEY_PASSWORD=...
./gradlew bundleRelease          # AAB برای Google Play / مایکت / بازار
```

### ۵) تست‌ها
```bash
./gradlew testDebugUnitTest      # AiEngineTest — خلاصه‌سازی، اهمیت، ارتباط، digest
```

### ۶) فعال‌سازی اعلان ابری (اختیاری)
۱. در کنسول Firebase پروژه بسازید و `google-services.json` را در `app/` بگذارید.
۲. در `app/build.gradle.kts` خط `id("com.google.gms.google-services")` را از کامنت خارج کنید.
۳. سرویس `NewsFlowFirebaseMessagingService` آماده است (type: breaking/digest/smart).

> بدون فایل گوگل، اپ کامل کار می‌کند؛ فقط push سرور غیرفعال است (اعلان‌های محلی Worker فعال‌اند).

---

## 🎨 هویت بصری
- لوگو: موج‌های سیال «جریان خبر» + نقطه سیگنال زنده → `branding/icon_source.png`
- گرادیان برند: `#7C4DFF → #00E5FF` روی زمینه `#0A0E1A`
- Adaptive Icon + Monochrome + فونت **وزیرمتن** (TTF باندل‌شده)
- موکاپ‌های ۱۰ صفحه در `../designs/` + گالری HTML (`designs/index.html`)
- Feature Graphic برای فروشگاه: `branding/feature_graphic.png`

## 📁 Assetهای فروشگاه
- آیکون ۵۱۲×۵۱۲: `branding/ic_launcher_play_512.png`
- متن معرفی فروشگاه: `docs/STORE_LISTING.md`

## 🔐 حریم خصوصی
تحلیل رفتار خوانش، **کاملاً روی دستگاه** انجام می‌شود (Room محلی). هیچ دیتای کاربر بدون اجازه منتقل نمی‌شود.

---

© 2026 NewsFlow AI — ساخته‌شده با Kotlin + Jetpack Compose · نسخه 1.0.0
