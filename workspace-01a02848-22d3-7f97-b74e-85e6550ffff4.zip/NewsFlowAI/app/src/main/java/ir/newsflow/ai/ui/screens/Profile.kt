package ir.newsflow.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.newsflow.ai.core.NewsCategory
import ir.newsflow.ai.core.Post
import ir.newsflow.ai.core.UserProfile
import ir.newsflow.ai.core.repo.ProfileRepository
import ir.newsflow.ai.data.ai.AiEngine.compactFa
import ir.newsflow.ai.data.ai.AiEngine.toFa
import ir.newsflow.ai.ui.components.*
import ir.newsflow.ai.ui.theme.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

data class ProfileUi(
    val profile: UserProfile? = null,
    val history: List<Post> = emptyList()
)

@HiltViewModel
class ProfileViewModel @Inject constructor(repo: ProfileRepository) : ViewModel() {
    val ui: StateFlow<ProfileUi> = combine(repo.profile(), repo.readHistory()) { p, h ->
        ProfileUi(p, h)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProfileUi())
}

@Composable
fun ProfileScreen(
    onOpenSettings: () -> Unit,
    onOpenPost: (String) -> Unit,
    onOpenAssistant: () -> Unit,
    vm: ProfileViewModel = hiltViewModel()
) {
    val ui by vm.ui.collectAsState()
    val p = ui.profile

    LazyColumn(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        /* کاور + آواتار */
        item {
            Box(Modifier.fillMaxWidth().height(190.dp)) {
                Box(
                    Modifier.fillMaxWidth().height(140.dp)
                        .background(Brush.linearGradient(listOf(BrandViolet.copy(.8f), BrandCyan.copy(.5f))))
                )
                IconButton(onClick = onOpenSettings, modifier = Modifier.padding(10.dp)) {
                    Icon(Icons.Filled.Settings, "تنظیمات", tint = Color.White)
                }
                Box(
                    Modifier.align(Alignment.BottomCenter).size(104.dp).clip(CircleShape)
                        .background(BgDark),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier.size(94.dp).clip(CircleShape).background(BrandGradient),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(p?.name?.take(2) ?: "ن", style = MaterialTheme.typography.headlineSmall,
                            color = Color.White)
                    }
                }
            }
            Column(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(p?.name ?: "", style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground)
                Text("عضو نیوزفلو از ${p?.joinedYear ?: "۱۴۰۳"} · سطح خوانش: حرفه‌ای 🏆",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        /* آمار */
        item {
            p?.let {
                GlassCard(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 16.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        StatItem("خبر خوانده‌شده", compactFa(it.readCount), BrandCyan)
                        VerticalDivider(Modifier.height(44.dp))
                        StatItem("ذخیره‌شده", compactFa(it.savedCount), Color(0xFFB39DFF))
                        VerticalDivider(Modifier.height(44.dp))
                        StatItem("کانال دنبال‌شده", it.followingCount.toFa(), BrandPink)
                    }
                }
            }
        }

        /* علایق استنباطی */
        if (!p?.interestsShare.isNullOrEmpty()) {
            item {
                SectionTitle("🎯 علایق خبری شما (تحلیل رفتار توسط AI)")
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                    p!!.interestsShare.forEach { (cat, pct) ->
                        InterestChip(cat, pct)
                        Spacer(Modifier.width(8.dp))
                    }
                }
            }
        }

        /* پیشنهاد هوشمند */
        item {
            GlassCard(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                contentPadding = PaddingValues(14.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().clickable(onClick = onOpenAssistant),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalButton(onClick = onOpenAssistant) { Text("شروع گفت‌وگو") }
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.End) {
                        Text("✨ تحلیل شخصی در دستیار هوشمند", style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface)
                        Text("الگوی خوانش شما + پیشنهاد محتوای بهتر",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.width(10.dp))
                    Icon(Icons.Filled.AutoAwesome, null, tint = BrandCyan)
                }
            }
        }

        /* تاریخچه مطالعه */
        item { SectionTitle("🕘 تاریخچه مطالعه") }
        if (ui.history.isEmpty()) {
            item {
                Text("هنوز خبری نخوانده‌اید — با مطالعه، پیشنهادها دقیق‌تر می‌شوند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp))
            }
        } else {
            items(ui.history.take(8), key = { "h_" + it.id }) { post ->
                GlassCard(
                    modifier = Modifier.fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                        .clickable { onOpenPost(post.id) },
                    contentPadding = PaddingValues(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(post.title, style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${post.channelName} · ${timeAgoFa(post.publishedAt)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.width(10.dp))
                        ChannelAvatar(post.channelName, post.channelId.hashCode().toLong(), size = 40.dp)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineSmall, color = color)
        Text(label, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun InterestChip(cat: NewsCategory, pct: Int) {
    Surface(
        color = BrandViolet.copy(alpha = .18f), shape = RoundedCornerShape(50)
    ) {
        Text("${cat.emoji} ${cat.fa} ${pct.toFa()}٪",
            style = MaterialTheme.typography.labelLarge, color = Color(0xFFC7B6FF),
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
    }
}
