package ir.newsflow.ai.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.newsflow.ai.R
import ir.newsflow.ai.core.NewsCategory
import ir.newsflow.ai.data.Prefs
import ir.newsflow.ai.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/* --------------------------------- اسپلش --------------------------------- */

@Composable
fun SplashScreen(onDone: (loggedIn: Boolean) -> Unit, vm: SplashViewModel = hiltViewModel()) {
    val alpha by rememberInfiniteTransition(label = "p").animateFloat(
        initialValue = .55f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "a"
    )
    LaunchedEffect(Unit) {
        delay(1600)
        onDone(vm.isLoggedIn())
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(listOf(BgDark, Color(0xFF10163A)))
            ),
        contentAlignment = Alignment.Center
    ) {
        // هاله‌های نور گلس
        Box(Modifier.size(420.dp).alpha(.5f)) {
            Box(Modifier.fillMaxSize().background(
                Brush.radialGradient(listOf(BrandViolet.copy(alpha = .4f), Color.Transparent))))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .size(132.dp)
                    .clip(RoundedCornerShape(38.dp))
                    .background(BrandGradient)
                    .alpha(alpha),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painterResource(R.drawable.app_logo), null,
                    modifier = Modifier.size(120.dp).clip(RoundedCornerShape(34.dp)),
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(Modifier.height(28.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("AI", style = MaterialTheme.typography.displayLarge,
                    color = BrandCyan)
                Spacer(Modifier.width(8.dp))
                Text("نیوزفلو", style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onBackground)
            }
            Spacer(Modifier.height(10.dp))
            Text("شبکه اجتماعی خبری هوشمند", style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(48.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(30.dp), strokeWidth = 3.dp,
                color = BrandCyan, trackColor = Color.White.copy(alpha = .1f)
            )
        }
    }
}

@HiltViewModel
class SplashViewModel @Inject constructor(private val prefs: Prefs) : ViewModel() {
    suspend fun isLoggedIn(): Boolean = prefs.settings.first().onboarded
}

/* ---------------------------------- ورود ---------------------------------- */

@Composable
fun LoginScreen(onEnter: () -> Unit, vm: LoginViewModel = hiltViewModel()) {
    val state by vm.ui.collectAsState()
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(listOf(BgDark, Color(0xFF141B3E))))
            .verticalScroll(rememberScrollState()),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.fillMaxWidth().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painterResource(R.drawable.app_logo), "لوگو",
                modifier = Modifier.size(92.dp).clip(RoundedCornerShape(26.dp))
            )
            Spacer(Modifier.height(22.dp))
            Text("به نیوزفلو خوش آمدید", style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.height(6.dp))
            Text(
                "اخبار مهم دنیا؛ خلاصه‌شده با هوش مصنوعی و شخصی‌سازی‌شده برای شما",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(30.dp))

            /* نام کاربر */
            OutlinedTextField(
                value = state.name, onValueChange = vm::onNameChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                label = { Text("نام شما (اختیاری)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrandCyan,
                    unfocusedBorderColor = Color.White.copy(alpha = .15f)
                )
            )
            Spacer(Modifier.height(18.dp))

            /* علایق */
            Text("علایق خبری‌تان را انتخاب کنید", style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
            Spacer(Modifier.height(10.dp))
            FlowRowSimple {
                NewsCategory.entries.filter { it != NewsCategory.ALL }.forEach { cat ->
                    val selected = cat.name in state.interests
                    FilterChip(
                        selected = selected,
                        onClick = { vm.toggleInterest(cat.name) },
                        label = { Text("${cat.emoji} ${cat.fa}") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BrandViolet.copy(alpha = .3f),
                            selectedLabelColor = Color(0xFFC7B6FF)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            borderColor = Color.White.copy(alpha = .15f),
                            selectedBorderColor = BrandViolet, enabled = true, selected = selected
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                }
            }

            Spacer(Modifier.height(28.dp))
            Button(
                onClick = { vm.login(onEnter) },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(28.dp),
                enabled = state.interests.isNotEmpty()
            ) { Text("شروع جریان خبری ⚡", style = MaterialTheme.typography.labelLarge) }

            Spacer(Modifier.height(12.dp))
            TextButton(onClick = { vm.loginAsGuest(onEnter) }) {
                Text("ادامه به‌عنوان مهمان", color = BrandCyan)
            }
            Spacer(Modifier.height(4.dp))
            Text("ورود با گوگل و شماره موبایل در نسخه کامل فعال می‌شود",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** ردیف‌چین ساده چیپ‌ها (بدون وابستگی اضافی) */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun FlowRowSimple(content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.FlowRow(
        horizontalArrangement = Arrangement.spacedBy(0.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) { content() }
}

data class LoginUi(val name: String = "", val interests: Set<String> = setOf("TECH", "AI"))

@HiltViewModel
class LoginViewModel @Inject constructor(private val prefs: Prefs) : ViewModel() {
    private val _ui = kotlinx.coroutines.flow.MutableStateFlow(LoginUi())
    val ui: kotlinx.coroutines.flow.StateFlow<LoginUi> = _ui

    fun onNameChange(v: String) { _ui.value = _ui.value.copy(name = v.take(30)) }

    fun toggleInterest(key: String) {
        val cur = _ui.value.interests.toMutableSet()
        if (key in cur) cur.remove(key) else cur.add(key)
        _ui.value = _ui.value.copy(interests = cur)
    }

    fun login(onEnter: () -> Unit) = viewModelScope.launch {
        prefs.login(_ui.value.name.ifBlank { "کاربر نیوزفلو" }, _ui.value.interests)
        onEnter()
    }

    fun loginAsGuest(onEnter: () -> Unit) = viewModelScope.launch {
        prefs.login("کاربر مهمان", _ui.value.interests)
        onEnter()
    }
}
