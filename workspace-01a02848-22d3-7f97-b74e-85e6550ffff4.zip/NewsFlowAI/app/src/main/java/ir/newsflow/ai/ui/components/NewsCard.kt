package ir.newsflow.ai.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.newsflow.ai.core.Importance
import ir.newsflow.ai.core.Post
import ir.newsflow.ai.core.ReactionType
import ir.newsflow.ai.data.ai.AiEngine.compactFa
import ir.newsflow.ai.data.ai.AiEngine.toFa
import ir.newsflow.ai.ui.theme.*

/**
 * کارت خبر نسل جدید — قلب فید اجتماعی نیوزفلو
 */
@Composable
fun NewsCard(
    post: Post,
    onOpen: () -> Unit,
    onSave: () -> Unit,
    onReact: (ReactionType?) -> Unit,
    onShare: () -> Unit,
    showAiBox: Boolean = true,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier = modifier.fillMaxWidth()) {
        /* --- هدر: کانال + زمان + نشان اهمیت --- */
        Row(
            Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ImportanceBadge(post.importanceLevel, post.importance)
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(post.channelName, style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface)
                    if (post.channelVerified) {
                        Spacer(Modifier.width(3.dp))
                        Icon(Icons.Filled.Verified, null, tint = BrandCyan, modifier = Modifier.size(14.dp))
                    }
                }
                Text("${timeAgoFa(post.publishedAt)} · ${post.category.fa}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(10.dp))
            ChannelAvatar(post.channelName, post.channelId.hashCode().toLong(), size = 40.dp)
        }

        /* --- تصویر اصلی + لایه خلاصه AI --- */
        if (showAiBox && post.imageRes.isNotEmpty()) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)) {
                CoverImage(post.imageRes, Modifier.fillMaxWidth().height(190.dp), corner = 16.dp)
                // لایه گرادیانی پایین تصویر + اسمارت-باکس
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0xCC0A0E1A)),
                                startY = 220f
                            )
                        )
                )
                Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.clip(RoundedCornerShape(50))
                                .background(BrandGradient)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("AI ⚡",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold),
                                color = Color.White)
                        }
                        Spacer(Modifier.width(8.dp))
                        Text("خلاصه هوش مصنوعی", style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF7FE8FF))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        post.aiBullets.firstOrNull().orEmpty(),
                        style = MaterialTheme.typography.bodySmall, color = Color(0xFFEAF0FF),
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        } else Spacer(Modifier.height(12.dp))

        /* --- عنوان و متن --- */
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text(post.title, style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.clickable(onClick = onOpen))
            Spacer(Modifier.height(6.dp))
            if (!showAiBox || post.imageRes.isEmpty()) {
                Text(post.body.take(140).trimEnd() + "…", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
        }

        /* --- نوار واکنش / ذخیره / اشتراک --- */
        ReactionBar(
            post = post,
            onOpen = onOpen, onSave = onSave, onReact = onReact, onShare = onShare,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}


@Composable
fun ReactionBar(
    post: Post,
    onOpen: () -> Unit,
    onSave: () -> Unit,
    onReact: (ReactionType?) -> Unit,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    val likeActive = post.myReaction == ReactionType.LIKE
    val likeTint by animateColorAsState(if (likeActive) BrandPink else MaterialTheme.colorScheme.onSurfaceVariant, label = "lk")
    Row(
        modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // اشتراک
        IconButton(onClick = onShare) {
            Icon(Icons.AutoMirrored.Filled.Send, "اشتراک", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.weight(1f))
        // ذخیره با شمارنده
        TextButton(onClick = onSave) {
            Icon(
                if (post.isSaved) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                "ذخیره", tint = if (post.isSaved) BrandCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(19.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text(compactFa(post.savesCount), style = MaterialTheme.typography.labelLarge,
                color = if (post.isSaved) BrandCyan else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.weight(1f))
        // آتش
        ReactionPill("🔥", "مفید", post.myReaction == ReactionType.FIRE, BrandAmber) {
            onReact(if (post.myReaction == ReactionType.FIRE) null else ReactionType.FIRE)
        }
        Spacer(Modifier.weight(1f))
        // لایک با شمارنده
        TextButton(onClick = { onReact(if (likeActive) null else ReactionType.LIKE) }) {
            Text("❤")
            Spacer(Modifier.width(4.dp))
            Text(compactFa(post.likeCount), style = MaterialTheme.typography.labelLarge, color = likeTint)
        }
    }
}


@Composable
fun ReactionPill(emoji: String, label: String, active: Boolean, activeColor: Color, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (active) activeColor.copy(alpha = .18f) else Color.Transparent, label = "rp"
    )
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emoji)
        if (active) {
            Spacer(Modifier.width(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = activeColor)
        }
    }
}
