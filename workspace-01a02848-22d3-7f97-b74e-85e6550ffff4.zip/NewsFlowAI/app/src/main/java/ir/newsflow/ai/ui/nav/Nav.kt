package ir.newsflow.ai.ui.nav

import androidx.annotation.DrawableRes
import androidx.compose.animation.*
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import ir.newsflow.ai.R
import ir.newsflow.ai.ui.screens.*
import ir.newsflow.ai.ui.theme.BgDark2
import ir.newsflow.ai.ui.theme.BrandCyan

object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val HOME = "home"
    const val DISCOVER = "discover"
    const val CHANNELS = "channels"
    const val SAVED = "saved"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val ASSISTANT = "assistant"
    const val DETAIL = "detail/{postId}"
    fun detail(id: String) = "detail/$id"
}

data class BottomItem(
    val route: String, val label: String, @DrawableRes val icon: Int
)

val bottomItems = listOf(
    BottomItem(Routes.PROFILE, "پروفایل", R.drawable.ic_person),
    BottomItem(Routes.SAVED, "ذخیره‌ها", R.drawable.ic_bookmark),
    BottomItem(Routes.CHANNELS, "کانال‌ها", R.drawable.ic_channels),
    BottomItem(Routes.DISCOVER, "کشف", R.drawable.ic_discover),
    BottomItem(Routes.HOME, "خانه", R.drawable.ic_home),
)

private val bottomVisibleOn = bottomItems.map { it.route }.toSet()

@Composable
fun NewsFlowNavHost(navController: NavHostController, startAtLogin: Boolean) {
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            AnimatedVisibility(
                visible = currentRoute in bottomVisibleOn,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                NewsFlowBottomBar(currentRoute) { item ->
                    navController.navigate(item.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = if (startAtLogin) Routes.LOGIN else Routes.SPLASH,
            modifier = Modifier.padding(bottom = if (currentRoute in bottomVisibleOn) padding.calculateBottomPadding() else 0.dp),
            enterTransition = { fadeIn() + slideInHorizontally(initialOffsetX = { it / 24 }) },
            exitTransition = { fadeOut() },
            popEnterTransition = { fadeIn() },
            popExitTransition = { fadeOut() + slideOutHorizontally(targetOffsetX = { it / 24 }) }
        ) {
            composable(Routes.SPLASH) { SplashScreen(onDone = { logged ->
                navController.navigate(if (logged) Routes.HOME else Routes.LOGIN) {
                    popUpTo(Routes.SPLASH) { inclusive = true }
                }
            }) }
            composable(Routes.LOGIN) { LoginScreen(onEnter = {
                navController.navigate(Routes.HOME) {
                    popUpTo(Routes.LOGIN) { inclusive = true }
                }
            }) }
            composable(Routes.HOME) { HomeScreen(
                onOpenPost = { navController.navigate(Routes.detail(it)) },
                onOpenAssistant = { navController.navigate(Routes.ASSISTANT) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            ) }
            composable(Routes.DISCOVER) { DiscoverScreen(
                onOpenPost = { navController.navigate(Routes.detail(it)) }) }
            composable(Routes.CHANNELS) { ChannelsHubScreen() }
            composable(Routes.SAVED) { SavedScreen(
                onOpenPost = { navController.navigate(Routes.detail(it)) }) }
            composable(Routes.PROFILE) { ProfileScreen(
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                onOpenPost = { navController.navigate(Routes.detail(it)) },
                onOpenAssistant = { navController.navigate(Routes.ASSISTANT) }) }
            composable(Routes.SETTINGS) { SettingsScreen(onBack = { navController.popBackStack() }) }
            composable(Routes.ASSISTANT) { AiAssistantScreen(onBack = { navController.popBackStack() }) }
            composable(Routes.DETAIL) { entry ->
                val id = entry.arguments?.getString("postId") ?: return@composable
                NewsDetailScreen(postId = id,
                    onBack = { navController.popBackStack() },
                    onOpenPost = { navController.navigate(Routes.detail(it)) })
            }
        }
    }
}

@Composable
fun NewsFlowBottomBar(currentRoute: String?, onSelect: (BottomItem) -> Unit) {
    NavigationBar(
        containerColor = BgDark2.copy(alpha = .96f),
        tonalElevation = 8.dp
    ) {
        bottomItems.forEach { item ->
            val selected = currentRoute == item.route
            NavigationBarItem(
                selected = selected,
                onClick = { onSelect(item) },
                icon = {
                    Icon(
                        painterResource(item.icon), item.label,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = BrandCyan,
                    selectedTextColor = BrandCyan,
                    indicatorColor = BrandCyan.copy(alpha = .14f),
                    unselectedIconColor = Color(0xFF8A93B2),
                    unselectedTextColor = Color(0xFF8A93B2)
                )
            )
        }
    }
}
