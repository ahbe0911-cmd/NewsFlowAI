package ir.newsflow.ai.data.repo

import ir.newsflow.ai.core.*
import ir.newsflow.ai.core.repo.ChannelRepository
import ir.newsflow.ai.core.repo.FeedRepository
import ir.newsflow.ai.core.repo.ProfileRepository
import ir.newsflow.ai.data.Prefs
import ir.newsflow.ai.data.ai.AiEngine
import ir.newsflow.ai.data.local.*
import ir.newsflow.ai.data.seed.SeedData
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

/**
 * پیاده‌سازی لایه داده — Repository Pattern + Offline-first (Room به‌عنوان SSOT)
 */
@Singleton
class NewsRepositoryImpl @Inject constructor(
    private val db: AppDatabase,
    private val prefs: Prefs
) : FeedRepository, ChannelRepository, ProfileRepository {

    private val seedMutex = Mutex()

    private suspend fun ensureSeeded() {
        seedMutex.withLock {
            if (db.channelDao().count() > 0) return
            val now = System.currentTimeMillis()
            val channels = SeedData.channels()
            val rawPosts = SeedData.posts(now)
            // محاسبه فیلدهای AI به هنگام ورود داده (manual pipeline)
            val posts = rawPosts.map { e ->
                val coverage = rawPosts.count {
                    AiEngine.keywords(it.title, 3).any { k -> e.title.contains(k) }
                }
                e.copy(
                    importance = AiEngine.importanceScore(
                        e.title, e.body, e.publishedAt, now,
                        channelCoverage = coverage, engagement = e.likeCount + e.savesCount * 3
                    )
                )
            }
            db.channelDao().upsertAll(channels)
            db.postDao().upsertAll(posts)
        }
    }

    /* ------------------------------- مپینگ ------------------------------- */
    private fun toPost(
        e: PostEntity,
        channels: Map<String, ChannelEntity>,
        saved: Set<String>,
        reactions: Map<String, ReactionType>
    ) = Post(
        id = e.id, channelId = e.channelId,
        channelName = channels[e.channelId]?.name ?: "",
        channelVerified = channels[e.channelId]?.verified ?: false,
        title = e.title, body = e.body, imageRes = e.imageRes,
        category = e.category, publishedAt = e.publishedAt,
        importance = e.importance,
        aiBullets = AiEngine.keyPoints(e.title, e.body),
        likeCount = e.likeCount, savesCount = e.savesCount, viewsCount = e.viewsCount,
        myReaction = reactions[e.id], isSaved = e.id in saved, sources = e.sources
    )

    private fun ChannelEntity.toModel() = Channel(
        id, name, username, category, followers, verified, avatarSeed, isFollowed, isSuggested
    )

    @OptIn(ExperimentalCoroutinesApi::class)
    private val combined: Flow<PostsState> = flow { ensureSeeded(); emit(Unit) }.flatMapLatest {
        combine(
            db.postDao().observeAll(),
            db.channelDao().observeAll(),
            db.savedDao().observeIds(),
            db.reactionDao().observeAll()
        ) { posts, channels, saved, reacts -> PostsState(posts, channels, saved, reacts) }
    }

    private data class PostsState(
        val posts: List<PostEntity>, val channels: List<ChannelEntity>,
        val saved: List<String>, val reacts: List<ReactionEntity>
    )

    private fun PostsState.toPosts(): List<Post> {
        val chMap = channels.associateBy { it.id }
        val rMap = reacts.associate { it.postId to it.type }
        return posts.map { toPost(it, chMap, saved.toSet(), rMap) }
    }

    /* ------------------------------- Feed ------------------------------- */
    override fun feed(category: NewsCategory, personal: Boolean): Flow<List<Post>> =
        combine(combined, prefs.settings) { state, settings -> state to settings }
            .map { (state, settings) ->
                val posts = state.toPosts()
                val filtered = if (category == NewsCategory.ALL) posts
                else posts.filter { it.category == category }
                if (!personal || !settings.personalize) return@map filtered.sortedByDescending { it.publishedAt }
                // امتیاز مجدد با علایق انتخابی کاربر (شخصی‌سازی)
                filtered.sortedByDescending {
                    AiEngine.personalizedScore(it, emptyMap(), settings.interests) * 0.7 +
                            it.publishedAt / 3_600_000.0
                }
            }

    override fun postById(id: String): Flow<Post?> =
        combined.map { state -> state.toPosts().firstOrNull { it.id == id } }

    override fun related(post: Post): Flow<List<Post>> =
        combined.map { state -> AiEngine.related(post, state.toPosts()) }

    override fun trendingTopics(limit: Int): Flow<List<Pair<String, Int>>> =
        combined.map { state ->
            val dayAgo = System.currentTimeMillis() - 86_400_000
            state.posts.filter { it.publishedAt >= dayAgo }
                .flatMap { AiEngine.keywords(it.title, 4) }
                .groupingBy { it }.eachCount()
                .entries.sortedByDescending { it.value }.take(limit)
                .map { it.key to it.value }
        }

    override fun hotToday(limit: Int): Flow<List<Post>> =
        combined.map { state -> state.toPosts().sortedByDescending { it.importance }.take(limit) }

    override fun suggestedForYou(limit: Int): Flow<List<Post>> =
        combine(combined, prefs.settings) { s, set -> s to set }.map { (state, set) ->
            state.toPosts().filter { it.category.name in set.interests }
                .sortedByDescending { it.importance + it.publishedAt / 86_400_000.0 }
                .take(limit)
        }

    /* ------------------------------ تعامل‌ها ------------------------------ */
    override suspend fun toggleSave(postId: String) {
        db.savedDao().observeIsSaved(postId).first().let { isSaved ->
            if (isSaved) { db.savedDao().remove(postId); db.postDao().bumpSaves(postId, -1) }
            else { db.savedDao().save(SavedEntity(postId, System.currentTimeMillis())); db.postDao().bumpSaves(postId, 1) }
        }
    }

    override suspend fun react(postId: String, type: ReactionType?) {
        val current = db.reactionDao().observeAll().first().firstOrNull { it.postId == postId }?.type
        when {
            type == null && current != null -> { db.reactionDao().clear(postId); db.postDao().bumpLikes(postId, -1) }
            type != null && current == null -> { db.reactionDao().set(ReactionEntity(postId, type)); db.postDao().bumpLikes(postId, 1) }
            type != null && current != type -> db.reactionDao().set(ReactionEntity(postId, type))
        }
    }

    override suspend fun markRead(postId: String) {
        combined.first().posts.firstOrNull { it.id == postId }?.let { e ->
            db.readDao().add(ReadEntity(postId = postId, category = e.category, readAt = System.currentTimeMillis()))
        }
    }

    /** سینک شبیه‌سازی‌شده — در نسخه واقعی، از کانال‌های تلگرام پست می‌خواند */
    override suspend fun refresh(): Result<Int> = runCatching {
        delay(1200) // شبیه‌سازی شبکه
        val channels = db.channelDao().observeFollowed().first()
        if (channels.isEmpty()) return@runCatching 0
        val now = System.currentTimeMillis()
        val ch = channels.random()
        val templates = listOf(
            "گزارش لحظه‌ای %c: خبر تازه‌ای برای مخاطبان نیوزفلو منتشر شد. جزئیات این رویداد در حال تکمیل است و کارشناسان در حال تحلیل زوایای آن هستند. آمارهای اولیه نشان از واکنش گسترده کاربران دارد و شاخص اهمیت آن رو به افزایش است.",
            "اطلاعیه جدید %c: موضوعی که امروز دست‌به‌دست می‌شد با سند تازه تأیید شد. منابع مطلع می‌گویند پیامدهای آن در روزهای آینده نمایان می‌شود و باید دید بازار و افکار عمومی چه واکنشی نشان می‌دهند.",
            "بروزرسانی %c: آخرین آمار رسمی این حوزه منتشر شد و ارقام، تغییر معناداری را نسبت به هفته گذشته نشان می‌دهند. تحلیلگران سه سناریوی محتمل را بررسی می‌کنند و توصیه می‌کنند خوانندگان اخبار تکمیلی را دنبال کنند."
        )
        val n = Random.nextInt(1, 3)
        val newPosts = (1..n).map { i ->
            val body = templates.random().replace("%c", ch.name)
            val title = when (ch.category) {
                NewsCategory.TECH -> "اختراع یا رونمایی تازه در دنیای فناوری (لحظاتی پیش)"
                NewsCategory.AI -> "پیشرفت تازه هوش مصنوعی؛ مدل جدید از راه رسید"
                NewsCategory.ECONOMY -> "خبر تازه بازار؛ تحلیل‌گران در حال ارزیابی"
                NewsCategory.SPORT -> "نتیجه و اتفاق تازه از رقابت‌های امروز"
                NewsCategory.SCIENCE -> "یافته جدید پژوهشگران اعلام شد"
                else -> "رویداد تازه فرهنگی و هنری"
            }
            PostEntity(
                id = "sync_${now}_$i", channelId = ch.id, title = title, body = body,
                imageRes = listOf("news_tech", "news_ai", "news_econ", "news_sport", "news_science").random(),
                category = ch.category, publishedAt = now - i * 60_000L,
                importance = AiEngine.importanceScore(title, body, now, now, engagement = 0),
                likeCount = (10..300).random(), savesCount = (5..120).random(), viewsCount = (100..5000).random(),
                sources = listOf(ch.username)
            )
        }
        db.postDao().upsertAll(newPosts)
        n
    }

    /* ------------------------------ کانال‌ها ------------------------------ */
    override fun channels(): Flow<List<Channel>> = flow { ensureSeeded(); emit(Unit) }
        .flatMapLatest { db.channelDao().observeAll() }
        .map { list -> list.map { it.toModel() } }

    override fun followed(): Flow<List<Channel>> = channels()
        .map { list -> list.filter { it.isFollowed } }

    override fun suggestions(): Flow<List<Channel>> = channels()
        .map { list -> list.filter { !it.isFollowed }.sortedByDescending { it.followers } }

    override suspend fun follow(id: String, follow: Boolean) = db.channelDao().setFollowed(id, follow)

    override suspend fun remove(id: String) = db.channelDao().deleteById(id)

    /**
     * افزودن کانال عمومی تلگرام — اسم به‌صورت @username یا لینک t.me/xxx
     * (نسخه آفلاین: اعتبارسنجی فرمت + ثبت لوکال؛ در نسخه کامل، TG API / وب‌پریویو)
     */
    override suspend fun addTelegramChannel(
        username: String, name: String, category: NewsCategory
    ): Result<Channel> = runCatching {
        val clean = username.trim()
            .removePrefix("https://t.me/").removePrefix("t.me/").removePrefix("@")
        require(clean.matches(Regex("[A-Za-z0-9_]{5,32}"))) { "یوزرنیم تلگرام معتبر نیست" }
        ensureSeeded()
        val entity = ChannelEntity(
            id = "tg_$clean", name = name.ifBlank { clean },
            username = "@$clean", category = category,
            followers = (1_000L..60_000L).random(), verified = false,
            avatarSeed = clean.sumOf { it.code }.toLong(), isFollowed = true, isSuggested = false
        )
        db.channelDao().upsert(entity)
        // پست خوش‌آمد: شبیه‌سازی ایمپورت آخرین مطلب کانال
        delay(600)
        val now = System.currentTimeMillis()
        val body = "آخرین مطلب کانال ${entity.name} با موفقیت به جریان خبری شما متصل شد؛ از این پس پست‌های جدید این کانال به‌صورت خودکار با هوش مصنوعی خلاصه، رتبه‌بندی اهمیت و استخراج نکته می‌شوند و در فید شما نمایش داده می‌شوند. برای مدیریت، به هاب کانال‌ها مراجعه کنید."
        db.postDao().upsertAll(listOf(PostEntity(
            "tg_${now}", entity.id, "کانال «${entity.name}» متصل شد ✔",
            body, "", category, now - 10_000,
            importance = AiEngine.importanceScore(entity.name, body, now, now),
            likeCount = 12, savesCount = 3, viewsCount = 200, sources = listOf(entity.username)
        )))
        entity.toModel()
    }

    /* ------------------------------ پروفایل ------------------------------ */
    override fun profile(): Flow<UserProfile> = combine(
        db.readDao().observeTotal(),
        db.savedDao().observeCount(),
        db.channelDao().observeFollowed(),
        db.readDao().observeCategoryCounts(),
        prefs.settings
    ) { reads, saved, channels, catCounts, settings ->
        val total = catCounts.sumOf { it.cnt }.coerceAtLeast(1)
        UserProfile(
            name = settings.userName.ifBlank { "کاربر نیوزفلو" },
            joinedYear = "۱۴۰۳",
            readCount = reads, savedCount = saved, followingCount = channels.size,
            interestsShare = catCounts.take(3)
                .map { it.category to (it.cnt * 100 / total) }
        )
    }

    override fun readHistory(limit: Int): Flow<List<Post>> =
        combine(combined, db.readDao().observeRecent(limit)) { state, reads ->
            val posts = state.toPosts().associateBy { it.id }
            reads.mapNotNull { posts[it.postId] }.distinctBy { it.id }
        }
}
