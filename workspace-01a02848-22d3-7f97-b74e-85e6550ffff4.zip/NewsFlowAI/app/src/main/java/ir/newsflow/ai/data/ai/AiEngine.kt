package ir.newsflow.ai.data.ai

import ir.newsflow.ai.core.DigestCard
import ir.newsflow.ai.core.Importance
import ir.newsflow.ai.core.Post
import kotlin.math.max
import kotlin.math.min

/**
 * AiEngine — موتور پردازش متن فارسی نیوزفلو
 *
 * نسخه ۱: پردازش کاملاً روی دستگاه (On-Device) برای حریم خصوصی و سرعت.
 * نسخه‌های بعدی می‌توانند به API مدل‌های بزرگ متصل شوند — این‌ترفیس از قبل جداشده است.
 */
object AiEngine {

    /* ------------------------------ واژه‌نامه فارسی ------------------------------ */
    private val stopWords = setOf(
        "که", "در", "به", "از", "و", "با", "برای", "این", "آن", "را", "تا", "بر", "یا",
        "هم", "شد", "است", "بود", "می", "خود", "باید", "وی", "ما", "شما", "آن‌ها", "اینکه",
        "اما", "اگر", "همه", "هر", "پس", "زیرا", "چون", "وقتی", "روی", "بین", "بیش", "دیگر",
        "کرد", "گفت", "شدند", "شده", "دارد", "دارند", "نیز", "او", "دولت", "اخبار"
    )

    private val highValuePatterns = listOf(
        "فوری", "رسمی", "شکست", "رکورد", "اولین", "اختصاصی", "هشدار", "گران", "جهش",
        "سقوط", "رونمایی", "معرفی شد", "دارایی", "انتخابات", "مذاکره", "آتش‌بس", "زمین‌لرزه",
        "تحریم", "ترابایت", "ماهواره", "فضانورد", "واکسن", "قهرمان", "صعود", "finale"
    )

    /* ------------------------------ اعداد فارسی ------------------------------ */
    fun Int.toFa(): String = toString().map { ch ->
        if (ch.isDigit()) "۰۱۲۳۴۵۶۷۸۹"[ch - '0'] else ch
    }.joinToString("")

    fun String.enDigitsToFa(): String = map { ch ->
        if (ch.isDigit()) "۰۱۲۳۴۵۶۷۸۹"[ch - '0'] else ch
    }.joinToString("")

    fun compactFa(n: Int): String = when {
        n >= 1_000_000 -> (n / 1_000_000).toFa() + " میلیون"
        n >= 1_000 -> (n / 1_000).toFa() + "هزار"
        else -> n.toFa()
    }

    /* --------------------------- تحلیل کلمات کلیدی --------------------------- */
    fun keywords(text: String, limit: Int = 8): List<String> {
        val counts = mutableMapOf<String, Int>()
        text.split(Regex("[^\\u0600-\\u06FFa-zA-Z0-9]+"))
            .map { it.trim() }
            .filter { it.length >= 3 && it !in stopWords && !it.all(Char::isDigit) }
            .forEach { counts[it] = (counts[it] ?: 0) + 1 }
        return counts.entries.sortedByDescending { it.value }.take(limit).map { it.key }
    }

    /* ------------------------------ خلاصه‌سازی ------------------------------ */
    private fun sentencesOf(body: String): List<String> =
        body.split(Regex("[.!؟?؛]"))
            .map { it.trim() }
            .filter { it.length >= 24 }

    /** خلاصه استخراجی: انتخاب مهم‌ترین جمله‌ها بر اساس فراوانی کلیدواژه‌ها */
    fun summarize(title: String, body: String, maxSentences: Int = 2): String {
        val sentences = sentencesOf(body)
        if (sentences.isEmpty()) return body.take(140)
        val keys = keywords("$title $body", 10).toSet()
        val ranked = sentences.mapIndexed { idx, s ->
            val score = s.split(" ").count { it in keys } * 3 +
                    (sentences.size - idx) + // جمله‌های ابتدایی مهم‌تر
                    highValuePatterns.count { s.contains(it) } * 2
            s.trim() to score
        }.sortedByDescending { it.second }
        return ranked.take(maxSentences).sortedBy { sentences.indexOf(it.first) }
            .joinToString(". ") { it.first } + "."
    }

    /** نکات کلیدی (بولت‌های جعبه AI) */
    fun keyPoints(title: String, body: String, count: Int = 3): List<String> {
        val sentences = sentencesOf(body)
        if (sentences.isEmpty()) return listOf(title)
        val keys = keywords("$title $body", 12).toSet()
        return sentences.mapIndexed { idx, s ->
            val score = s.split(" ").count { it in keys } * 2 + (sentences.size - idx)
            short(s) to score
        }.sortedByDescending { it.second }.take(count).map { it.first }
    }

    private fun short(s: String, maxLen: Int = 95): String {
        val t = s.trim()
        return if (t.length <= maxLen) t else t.take(maxLen).trimEnd() + "…"
    }

    /* ------------------------------ نمره اهمیت ------------------------------ */
    /**
     * importance 0..100 = ترکیب:
     *  - ۴۰٪ کلمات باارزش / الگوهای «فوری»
     *  - ۲۵٪ تازگی خبر
     *  - ۲۰٪ پوشش چندکانالی (خبر تکراری = موضوع داغ)
     *  - ۱۵٪ تعامل کاربران
     */
    fun importanceScore(
        title: String, body: String, publishedAt: Long, now: Long = System.currentTimeMillis(),
        channelCoverage: Int = 1, engagement: Int = 0
    ): Int {
        val text = "$title $body"
        val patternHits = highValuePatterns.count { text.contains(it) }
        val patternScore = min(40, patternHits * 10)
        val hoursOld = max(0, (now - publishedAt) / 3_600_000.0)
        val freshness = (25 * (1.0 - min(1.0, hoursOld / 48.0))).toInt()
        val coverage = min(20, (channelCoverage - 1) * 7)
        val engage = min(15, engagement / 200)
        return min(100, max(5, patternScore + freshness + coverage + engage))
    }

    /* ------------------------------ اخبار مرتبط ------------------------------ */
    fun related(target: Post, all: List<Post>, limit: Int = 3): List<Post> {
        val targetKeys = keywords(target.title + " " + target.body, 10).toSet()
        return all.filter { it.id != target.id }
            .map { p ->
                val ks = keywords(p.title + " " + p.body, 10).toSet()
                val overlap = targetKeys.intersect(ks).size * 3 +
                        (if (p.category == target.category) 2 else 0)
                p to overlap
            }
            .filter { it.second >= 3 }
            .sortedWith(compareByDescending<Pair<Post, Int>> { it.second }
                .thenByDescending { it.first.importance })
            .take(limit).map { it.first }
    }

    /* ------------------------------ مقایسه دو خبر ------------------------------ */
    fun compare(a: Post, b: Post): Pair<String, List<String>> {
        val ka = keywords(a.title + " " + a.body, 10).toSet()
        val kb = keywords(b.title + " " + b.body, 10).toSet()
        val common = ka.intersect(kb)
        val verdict = when {
            common.size >= 5 -> "این دو خبر درباره یک رویداد مركزي هستند و مکمل‌اند."
            common.size >= 2 -> "موضوعات مشترکی دارند؛ خبر دوم زاویه دیگری از ماجرا را پوشش می‌دهد."
            else -> "این دو خبر مستقل‌اند اما در دسته ${a.category.fa} قرار می‌گیرند."
        }
        val bullets = listOf(
            "موضوع مشترک: ${if (common.isEmpty()) "—" else common.take(4).joinToString("، ")}",
            "اهمیت AI: خبر اول ${a.importance.toFa()}٪ / خبر دوم ${b.importance.toFa()}٪",
            "زاویه پوشش: «${short(a.title, 40)}» در برابر «${short(b.title, 40)}»"
        )
        return verdict to bullets
    }

    /* ------------------------------ خلاصه روزانه ------------------------------ */
    fun dailyDigest(posts: List<Post>, now: Long = System.currentTimeMillis()): DigestCard {
        val dayAgo = now - 24 * 3_600_000
        val today = posts.filter { it.publishedAt >= dayAgo }.sortedByDescending { it.importance }
        val items = today.take(4).map { it.importanceLevel to short(it.title, 78) }
        // یافتن «ارتباط پنهان» بین خبرهای داغ — موضوعی که در چند خبر تکرار می‌شود
        val allKeys = today.take(12).flatMap { p ->
            keywords(p.title + " " + p.body, 6).map { it to p }
        }
        val hidden = allKeys.groupBy { it.first }
            .filter { it.value.map { p -> p.second.channelId }.distinct().size >= 2 && it.key.length >= 3 }
            .maxByOrNull { it.value.size }
        val hint = if (hidden != null)
            "موضوع «${hidden.key}» امروز بین ${hidden.value.map { it.second.channelId }.distinct().size} کانال مشترک است — رویدادی در حال شکل‌گیری است."
        else "امروز اخبار پراکنده‌اند؛ رویداد غالب مشخصی شکل نگرفته است."
        return DigestCard(
            title = "خلاصه روزانه نیوزفلو",
            totalAnalyzed = today.size,
            items = items,
            connectionHint = hint
        )
    }

    /* ------------------------------ پیشنهاد شخصی ------------------------------ */
    /** امتیازدهی مجدد به فید بر اساس علاقه‌مندی‌های استنباط‌شده از رفتار کاربر */
    fun personalizedScore(post: Post, affinity: Map<String, Int>, interests: Set<String>): Int {
        var score = post.importance
        val catAff = affinity[post.category.name] ?: 0
        score += min(20, catAff * 3)
        if (post.category.name in interests) score += 12
        return score
    }
}
