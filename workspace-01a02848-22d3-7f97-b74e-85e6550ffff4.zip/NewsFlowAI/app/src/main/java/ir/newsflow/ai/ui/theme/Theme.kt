package ir.newsflow.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import ir.newsflow.ai.R

/* ------------------------------ سیستم رنگ برند ------------------------------ */
val BrandViolet = Color(0xFF7C4DFF)
val BrandCyan = Color(0xFF00E5FF)
val BrandPink = Color(0xFFFF3B6B)
val BrandAmber = Color(0xFFFFB300)
val SuccessGreen = Color(0xFF3DDC84)

val BgDark = Color(0xFF0A0E1A)
val BgDark2 = Color(0xFF0D1327)
val SurfaceDark = Color(0xFF151B31)
val SurfaceDark2 = Color(0xFF1A2138)
val TextPrimaryDark = Color(0xFFF2F5FF)
val TextSecondaryDark = Color(0xFF8A93B2)
val TextMutedDark = Color(0xFF566080)

val BgLight = Color(0xFFF4F6FC)
val SurfaceLight = Color(0xFFFFFFFF)
val TextPrimaryLight = Color(0xFF0D1327)
val TextSecondaryLight = Color(0xFF5A6478)

/** گرادیان اختصاصی برند */
val BrandGradient = Brush.linearGradient(listOf(BrandViolet, BrandCyan))
val BrandGradientSoft = Brush.linearGradient(listOf(BrandViolet.copy(alpha = .22f), BrandCyan.copy(alpha = .12f)))

private val DarkColors = darkColorScheme(
    primary = BrandViolet, onPrimary = Color.White,
    secondary = BrandCyan, onSecondary = BgDark,
    tertiary = BrandPink,
    background = BgDark, onBackground = TextPrimaryDark,
    surface = SurfaceDark, onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceDark2, onSurfaceVariant = TextSecondaryDark,
    error = BrandPink, outline = Color(0xFF2A3050)
)

private val LightColors = lightColorScheme(
    primary = BrandViolet, onPrimary = Color.White,
    secondary = Color(0xFF00838F), onSecondary = Color.White,
    tertiary = BrandPink,
    background = BgLight, onBackground = TextPrimaryLight,
    surface = SurfaceLight, onSurface = TextPrimaryLight,
    surfaceVariant = Color(0xFFECEFF8), onSurfaceVariant = TextSecondaryLight,
    error = BrandPink, outline = Color(0xFFD5DAEC)
)

/* ------------------------------- فونت وزیر ------------------------------- */
val Vazir = FontFamily(
    Font(R.font.vazir, FontWeight.Normal),
    Font(R.font.vazir_medium, FontWeight.Medium),
    Font(R.font.vazir_bold, FontWeight.Bold),
    Font(R.font.vazir_black, FontWeight.ExtraBold)
)

private fun faStyle(size: Float, weight: FontWeight, heightEm: Float = 1.9f) = TextStyle(
    fontFamily = Vazir, fontWeight = weight,
    fontSize = size.sp, lineHeight = (size * heightEm).sp
)

@Composable
fun NewsFlowTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    fontScale: Float = 1f,
    content: @Composable () -> Unit
) {
    val typography = remember(fontScale) {
        fun s(v: Float) = v * fontScale
        Typography(
            displayLarge = faStyle(s(30f), FontWeight.ExtraBold, 1.6f),
            headlineSmall = faStyle(s(21f), FontWeight.ExtraBold, 1.5f),
            titleLarge = faStyle(s(18f), FontWeight.Bold, 1.55f),
            titleMedium = faStyle(s(15.5f), FontWeight.Bold, 1.7f),
            titleSmall = faStyle(s(13.5f), FontWeight.Medium, 1.6f),
            bodyLarge = faStyle(s(14.5f), FontWeight.Normal, 2.0f),
            bodyMedium = faStyle(s(13f), FontWeight.Normal, 2.0f),
            bodySmall = faStyle(s(11.5f), FontWeight.Normal, 1.9f),
            labelLarge = faStyle(s(13f), FontWeight.Bold, 1.4f),
            labelSmall = faStyle(s(10.5f), FontWeight.Medium, 1.5f)
        )
    }
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = typography,
        content = content
    )
}

/** زمان «x پیش» به فارسی */
fun timeAgoFa(millis: Long): String {
    val diff = System.currentTimeMillis() - millis
    val min = diff / 60_000
    val hour = diff / 3_600_000
    val day = diff / 86_400_000
    fun fa(n: Long) = n.toString().map { if (it.isDigit()) "۰۱۲۳۴۵۶۷۸۹"[it - '0'] else it }.joinToString("")
    return when {
        min < 1 -> "هم‌اکنون"
        min < 60 -> "${fa(min)} دقیقه پیش"
        hour < 24 -> "${fa(hour)} ساعت پیش"
        day < 7 -> "${fa(day)} روز پیش"
        else -> "${fa(day / 7)} هفته پیش"
    }
}
