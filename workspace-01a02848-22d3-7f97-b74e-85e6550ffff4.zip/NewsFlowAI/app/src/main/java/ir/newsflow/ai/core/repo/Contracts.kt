package ir.newsflow.ai.core.repo

import ir.newsflow.ai.core.*
import kotlinx.coroutines.flow.Flow

/**
 * Contract های لایه دامنه — Clean Architecture (Interface segregation)
 */
interface FeedRepository {
    fun feed(category: NewsCategory = NewsCategory.ALL, personal: Boolean = true): Flow<List<Post>>
    fun postById(id: String): Flow<Post?>
    fun related(post: Post): Flow<List<Post>>
    fun trendingTopics(limit: Int = 6): Flow<List<Pair<String, Int>>>  // هشتگ/کلیدواژه → تعداد
    fun hotToday(limit: Int = 5): Flow<List<Post>>
    fun suggestedForYou(limit: Int = 4): Flow<List<Post>>

    suspend fun toggleSave(postId: String)
    suspend fun react(postId: String, type: ReactionType?)
    suspend fun markRead(postId: String)
    suspend fun refresh(): Result<Int>           // شبیه‌سازی سینک — تعداد پست جدید
}

interface ChannelRepository {
    fun channels(): Flow<List<Channel>>
    fun followed(): Flow<List<Channel>>
    suspend fun follow(id: String, follow: Boolean)
    suspend fun addTelegramChannel(username: String, name: String, category: NewsCategory): Result<Channel>
    suspend fun remove(id: String)
    fun suggestions(): Flow<List<Channel>>
}

interface ProfileRepository {
    fun profile(): Flow<UserProfile>
    fun readHistory(limit: Int = 15): Flow<List<Post>>
}
