package ir.newsflow.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.rememberNavController
import dagger.hilt.android.AndroidEntryPoint
import ir.newsflow.ai.data.Prefs
import ir.newsflow.ai.data.ThemeMode
import ir.newsflow.ai.notif.DailyDigestWorker
import ir.newsflow.ai.notif.InstantCheckWorker
import ir.newsflow.ai.ui.nav.NewsFlowNavHost
import ir.newsflow.ai.ui.theme.NewsFlowTheme
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // زمان‌بندی پس‌زمینه‌ای: خلاصه روزانه ۱۷:۰۰ + بررسی فوری هر ۳ ساعت
        DailyDigestWorker.schedule(applicationContext)
        InstantCheckWorker.schedule(applicationContext)

        setContent {
            val settings by prefs.settings.collectAsState(initial = Prefs.Settings())
            val dark = when (settings.themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            NewsFlowTheme(darkTheme = dark, fontScale = settings.fontScale) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = androidx.compose.material3.MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    NewsFlowNavHost(navController, startAtLogin = false)
                }
            }
        }
    }
}
