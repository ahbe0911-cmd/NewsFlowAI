package ir.newsflow.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.newsflow.ai.core.Channel
import ir.newsflow.ai.core.NewsCategory
import ir.newsflow.ai.core.repo.ChannelRepository
import ir.newsflow.ai.data.ai.AiEngine.compactFa
import ir.newsflow.ai.data.ai.AiEngine.toFa
import ir.newsflow.ai.ui.components.ChannelAvatar
import ir.newsflow.ai.ui.components.GlassCard
import ir.newsflow.ai.ui.components.SectionTitle
import ir.newsflow.ai.ui.theme.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HubUi(
    val followed: List<Channel> = emptyList(),
    val suggested: List<Channel> = emptyList(),
    val totalPostsToday: Int = 0,
    val showAdd: Boolean = false,
    val addError: String? = null,
    val snack: String? = null
)

@HiltViewModel
class ChannelsHubViewModel @Inject constructor(private val repo: ChannelRepository) : ViewModel() {
    private val showAdd = MutableStateFlow(false)
    private val error = MutableStateFlow<String?>(null)
    private val snack = MutableStateFlow<String?>(null)

    val ui: StateFlow<HubUi> = combine(
        repo.followed(), repo.suggestions(), showAdd, error
    ) { f, s, sh, e -> HubUi(f, s, 0, sh, e) }
        .combine(snack) { ui, s -> ui.copy(snack = s) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HubUi())

    fun toggleAdd(show: Boolean) { showAdd.value = show; error.value = null }
    fun follow(id: String, follow: Boolean) = viewModelScope.launch { repo.follow(id, follow) }
    fun remove(id: String) = viewModelScope.launch { repo.remove(id) }

    fun add(username: String, name: String, category: NewsCategory) = viewModelScope.launch {
        val r = repo.addTelegramChannel(username, name, category)
        r.onSuccess {
            showAdd.value = false
            showSnack("«${it.name}» متصل شد و اولین مطلب آن ایمپورت شد")
        }.onFailure { error.value = it.message }
    }

    private suspend fun showSnack(msg: String) {
        snack.value = msg
        kotlinx.coroutines.delay(2600)
        snack.value = null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChannelsHubScreen(vm: ChannelsHubViewModel = hiltViewModel()) {
    val ui by vm.ui.collectAsState()
    val snackbarHost = remember { SnackbarHostState() }
    LaunchedEffect(ui.snack) { ui.snack?.let { snackbarHost.showSnackbar(it) } }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        LazyColumn(contentPadding = PaddingValues(bottom = 100.dp)) {
            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalButton(onClick = { vm.toggleAdd(true) }) {
                        Icon(Icons.Filled.Add, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp)); Text("افزودن کانال")
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("هاب کانال‌ها 📡", style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground)
                        Text("کانال‌های تلگرام خود را متصل کنید",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            item { SectionTitle("کانال‌های دنبال‌شده (${ui.followed.size.toFa()})") }
            items(ui.followed, key = { it.id }) { ch ->
                ChannelRow(ch = ch, isFollowed = true,
                    onToggle = { vm.follow(ch.id, false) },
                    onDelete = { if (ch.id.startsWith("tg_")) vm.remove(ch.id) })
            }

            item { SectionTitle("✨ پیشنهاد هوشمند / کانال‌های محبوب") }
            items(ui.suggested, key = { "s_${it.id}" }) { ch ->
                ChannelRow(ch = ch, isFollowed = false, onToggle = { vm.follow(ch.id, true) }, onDelete = {})
            }
        }
        SnackbarHost(snackbarHost, Modifier.align(Alignment.TopCenter))

        if (ui.showAdd) {
            AddChannelDialog(
                error = ui.addError,
                onDismiss = { vm.toggleAdd(false) },
                onConfirm = { u, n, c -> vm.add(u, n, c) }
            )
        }
    }
}

@Composable
private fun ChannelRow(ch: Channel, isFollowed: Boolean, onToggle: () -> Unit, onDelete: () -> Unit) {
    GlassCard(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp),
        contentPadding = PaddingValues(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (isFollowed) {
                Switch(checked = true, onCheckedChange = { onToggle() })
            } else {
                TextButton(onClick = onToggle) {
                    Text("+ دنبال‌کردن", style = MaterialTheme.typography.labelLarge, color = BrandCyan)
                }
            }
            if (ch.id.startsWith("tg_")) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, "حذف", tint = BrandPink, modifier = Modifier.size(19.dp))
                }
            }
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(ch.name, style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface)
                    if (ch.verified) {
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Filled.Verified, null, tint = BrandCyan, modifier = Modifier.size(15.dp))
                    }
                }
                Text("${ch.username} · ${compactFa(ch.followers.toInt())} دنبال‌کننده · ${ch.category.fa}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(12.dp))
            ChannelAvatar(ch.name, ch.avatarSeed, size = 48.dp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddChannelDialog(
    error: String?,
    onDismiss: () -> Unit,
    onConfirm: (username: String, name: String, category: NewsCategory) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(NewsCategory.TECH) }
    var expanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = BgDark2,
        title = {
            Text("اتصال کانال عمومی تلگرام", style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
        },
        text = {
            Column {
                OutlinedTextField(
                    value = username, onValueChange = { username = it },
                    label = { Text("@یوزرنیم یا لینک t.me") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    isError = error != null
                )
                if (error != null) Text(error, color = BrandPink, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("نام نمایشی (اختیاری)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                )
                Spacer(Modifier.height(10.dp))
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(
                        value = "${category.emoji} ${category.fa}", onValueChange = {}, readOnly = true,
                        label = { Text("دسته‌بندی") }, modifier = Modifier.fillMaxWidth().menuAnchor(),
                        shape = RoundedCornerShape(16.dp)
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        NewsCategory.entries.filter { it != NewsCategory.ALL }.forEach { c ->
                            DropdownMenuItem(text = { Text("${c.emoji} ${c.fa}") },
                                onClick = { category = c; expanded = false })
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("پست‌های کانال به‌صورت خودکار با AI خلاصه و رتبه‌بندی می‌شوند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(username, name, category) },
                enabled = username.isNotBlank()) { Text("اتصال") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
