package ir.newsflow.ai.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.newsflow.ai.core.AssistantMessage
import ir.newsflow.ai.core.Importance
import ir.newsflow.ai.core.repo.FeedRepository
import ir.newsflow.ai.data.Prefs
import ir.newsflow.ai.data.ai.AiEngine
import ir.newsflow.ai.data.ai.AiEngine.toFa
import ir.newsflow.ai.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.math.max

enum class AssistantCommand(val label: String, val emoji: String) {
    DAILY_DIGEST("خلاصه روزانه", "📰"),
    TOP_IMPORTANT("خبرهای فوری امروز", "🚨"),
    COMPARE("مقایسه داغ‌ترین‌ها", "⚖"),
    CONNECT("ارتباط پنهان‌ها", "🔗"),
    SUGGEST("پیشنهاد برای من", "🎯"),
    SUMMARIZE_FIRST("خلاصه اولین خبر", "⚡")
}

@HiltViewModel
class AssistantViewModel @Inject constructor(
    private val feed: FeedRepository,
    private val prefs: Prefs
) : ViewModel() {

    private var msgId = 1L
    private val _messages = MutableStateFlow<List<AssistantMessage>>(emptyList())
    val messages: StateFlow<List<AssistantMessage>> = _messages
    private val _typing = MutableStateFlow(false)
    val typing: StateFlow<Boolean> = _typing
    var digestSent = false
        private set

    init {
        aiSay("سلام! من دستیار خبری نیوزفلو هستم ✨\nمی‌توانم اخبار را خلاصه کنم، اهمیت‌شان را تحلیل کنم و پیوندهای پنهان بین رویدادها را پیدا کنم. از اقدام‌های سریع شروع کنید یا سوال‌تان را بپرسید.")
    }

    private fun aiSay(text: String, bullets: List<String> = emptyList(), digest: ir.newsflow.ai.core.DigestCard? = null) {
        _messages.value = _messages.value + AssistantMessage(msgId++, true, text, bullets, digest)
    }

    private fun userSay(text: String) {
        _messages.value = _messages.value + AssistantMessage(msgId++, false, text)
    }

    fun runCommand(cmd: AssistantCommand) = viewModelScope.launch {
        userSay("${cmd.emoji} ${cmd.label}")
        _typing.value = true
        delay(if (cmd == AssistantCommand.DAILY_DIGEST) 1400 else 900)
        val posts = feed.feed().first()
        when (cmd) {
            AssistantCommand.DAILY_DIGEST -> {
                val d = AiEngine.dailyDigest(posts)
                digestSent = true
                aiSay("تحلیل کامل امروز آماده شد (${d.totalAnalyzed.toFa()} خبر):", digest = d)
            }
            AssistantCommand.TOP_IMPORTANT -> {
                val tops = posts.filter { it.importanceLevel != Importance.NORMAL }.take(4)
                aiSay("این‌ها مهم‌ترین خبرهای الان هستند:",
                    tops.map { "${it.importanceLevel.fa} ${it.importance.toFa()}٪ — ${it.title} (${it.channelName})" })
            }
            AssistantCommand.COMPARE -> {
                val hot = posts.sortedByDescending { it.importance }.take(2)
                if (hot.size == 2) {
                    val (verdict, bullets) = AiEngine.compare(hot[0], hot[1])
                    aiSay(verdict, bullets)
                } else aiSay("برای مقایسه، خبر کافی در فید نیست.")
            }
            AssistantCommand.CONNECT -> {
                val d = AiEngine.dailyDigest(posts)
                aiSay("🔎 تحلیل پیوندها:", listOf(d.connectionHint,
                    "کانال‌های شما امروز ${d.totalAnalyzed.toFa()} پست تولید کرده‌اند.",
                    "موضوعات تکراری بین کانال‌ها به معنای «رویداد در حال شکل‌گیری» است."))
            }
            AssistantCommand.SUGGEST -> {
                val s = prefs.settings.first()
                aiSay("بر اساس علایق شما (${s.interests.joinToString("، ")}) این‌ها را پیشنهاد می‌کنم:",
                    AiEngine.keywords(posts.filter { it.category.name in s.interests }
                        .joinToString(" ") { it.title }, 5)
                        .map { "🔹 موضوع «$it» امروز برای سلیقه شما جذاب است" })
            }
            AssistantCommand.SUMMARIZE_FIRST -> {
                posts.firstOrNull()?.let {
                    aiSay("خلاصه «${it.title}»:",
                        listOf(AiEngine.summarize(it.title, it.body)) + it.aiBullets.take(2))
                } ?: aiSay("خبری برای خلاصه‌سازی پیدا نشد.")
            }
        }
        _typing.value = false
    }

    fun ask(text: String) = viewModelScope.launch {
        if (text.isBlank()) return@launch
        userSay(text)
        _typing.value = true
        delay(900)
        val posts = feed.feed().first()
        val words = AiEngine.keywords(text, 3)
        val found = posts.filter { p -> words.any { p.title.contains(it) || p.body.contains(it) } }.take(3)
        when {
            found.isNotEmpty() -> aiSay("در اخبار امروز این موارد پیدا کردم:",
                found.map { "«${it.title}» — ${it.channelName} (اهمیت ${it.importance.toFa()}٪)" })
            text.contains("خلاصه") -> {
                val d = AiEngine.dailyDigest(posts)
                aiSay("خلاصه کلی امروز:", d.items.map { "${it.first.fa}: ${it.second}" })
            }
            else -> aiSay("متأسفانه خبر مرتبطی پیدا نکردم. پرسش‌تان را با کلمات کلیدی ساده‌تر بپرسید، یا از اقدام‌های سریع استفاده کنید.")
        }
        _typing.value = false
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(onBack: () -> Unit, vm: AssistantViewModel = hiltViewModel()) {
    val messages by vm.messages.collectAsState()
    val typing by vm.typing.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("دستیار خبری AI ✨", style = MaterialTheme.typography.titleMedium)
                        Text("آنلاین · پردازش روی دستگاه", style = MaterialTheme.typography.labelSmall,
                            color = SuccessGreen)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "بازگشت") }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            Column {
                /* اقدام‌های سریع */
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    reverseLayout = true
                ) {
                    items(AssistantCommand.entries.toList()) { cmd ->
                        SuggestionChip(
                            onClick = { vm.runCommand(cmd) },
                            label = { Text("${cmd.emoji} ${cmd.label}") },
                            modifier = Modifier.padding(horizontal = 3.dp)
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 12.dp, top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledIconButton(
                        onClick = { vm.ask(input); input = "" },
                        modifier = Modifier.size(50.dp).clip(CircleShape),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = BrandViolet)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, "ارسال", tint = Color.White)
                    }
                    Spacer(Modifier.width(8.dp))
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("از دستیار بپرسید…") },
                        singleLine = true,
                        shape = RoundedCornerShape(25.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandCyan,
                            unfocusedBorderColor = Color.White.copy(alpha = .15f)
                        )
                    )
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                MessageBubble(msg)
            }
            if (typing) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AiAvatar()
                        Spacer(Modifier.width(8.dp))
                        Text("در حال تحلیل…", style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFC7B6FF))
                    }
                }
            }
        }
    }
}

@Composable
private fun AiAvatar() {
    Box(
        Modifier.size(34.dp).clip(CircleShape).background(BrandGradient),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Filled.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(17.dp)) }
}

@Composable
private fun MessageBubble(msg: AssistantMessage) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.fromAi) Arrangement.Start else Arrangement.End
    ) {
        if (msg.fromAi) { AiAvatar(); Spacer(Modifier.width(8.dp)) }
        Column(
            Modifier
                .widthIn(max = 300.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 18.dp, topEnd = 18.dp,
                        bottomStart = if (msg.fromAi) 4.dp else 18.dp,
                        bottomEnd = if (msg.fromAi) 18.dp else 4.dp
                    )
                )
                .then(
                    if (msg.fromAi) Modifier.background(BrandGradientSoft)
                        .border(1.dp, BrandViolet.copy(.35f), RoundedCornerShape(18.dp))
                    else Modifier.background(BrandGradient)
                )
                .padding(12.dp)
        ) {
            Text(msg.text, style = MaterialTheme.typography.bodyMedium,
                color = if (msg.fromAi) MaterialTheme.colorScheme.onSurface else Color.White)
            msg.bullets.forEach {
                Spacer(Modifier.height(5.dp))
                Text(it, style = MaterialTheme.typography.bodySmall,
                    color = if (msg.fromAi) MaterialTheme.colorScheme.onSurfaceVariant
                    else Color.White.copy(alpha = .85f))
            }
            msg.digestCard?.let { card ->
                Spacer(Modifier.height(8.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = BgDark2),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("🗞 ${card.title}", style = MaterialTheme.typography.titleSmall,
                            color = Color.White)
                        Text("${card.totalAnalyzed.toFa()} خبر امروز تحلیل شد",
                            style = MaterialTheme.typography.labelSmall, color = BrandCyan)
                        Spacer(Modifier.height(8.dp))
                        card.items.forEach { (imp, title) ->
                            val dot = when (imp) { Importance.BREAKING -> "🔴"; Importance.HIGH -> "🟡"; else -> "🟢" }
                            Text("$dot ${imp.fa}: $title", style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFD5DAF0))
                            Spacer(Modifier.height(4.dp))
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("🔗 ${card.connectionHint}", style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF7FE8FF))
                    }
                }
            }
        }
        if (!msg.fromAi) Spacer(Modifier.width(8.dp))
    }
}
