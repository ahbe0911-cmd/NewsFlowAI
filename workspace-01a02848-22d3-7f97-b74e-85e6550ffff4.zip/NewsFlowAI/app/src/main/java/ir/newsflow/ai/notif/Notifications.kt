package ir.newsflow.ai.notif

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import ir.newsflow.ai.MainActivity
import ir.newsflow.ai.R
import ir.newsflow.ai.core.repo.FeedRepository
import ir.newsflow.ai.data.Prefs
import ir.newsflow.ai.data.ai.AiEngine
import kotlinx.coroutines.flow.first
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** کمک‌کلاس اعلان‌ها: سه کانال (فوری / خلاصه روزانه / پیشنهاد هوشمند) */
class NotificationHelper(private val context: Context) {

    companion object {
        const val CH_BREAKING = "nf_breaking"
        const val CH_DIGEST = "nf_digest"
        const val CH_SMART = "nf_smart"
        const val REQ_MAIN = 100
    }

    private val manager get() = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    init { createChannels() }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val breaking = NotificationChannel(CH_BREAKING, "اخبار فوری", NotificationManager.IMPORTANCE_HIGH)
                .apply { description = "رویدادهای مهم که AI تشخیص داده"; enableVibration(true) }
            val digest = NotificationChannel(CH_DIGEST, "خلاصه روزانه", NotificationManager.IMPORTANCE_DEFAULT)
            val smart = NotificationChannel(CH_SMART, "پیشنهاد هوشمند", NotificationManager.IMPORTANCE_LOW)
            listOf(breaking, digest, smart).forEach(manager::createNotificationChannel)
        }
    }

    private fun openAppIntent(deepLinkPost: String? = null): PendingIntent {
        val i = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        deepLinkPost?.let { i.putExtra("postId", it) }
        return PendingIntent.getActivity(context, REQ_MAIN, i, PendingIntent.FLAG_IMMUTABLE)
    }

    fun notifyBreaking(title: String, text: String, postId: String? = null) {
        push(CH_BREAKING, title, text, postId, NotificationCompat.PRIORITY_HIGH)
    }

    fun notifyDigest(title: String, text: String) {
        push(CH_DIGEST, title, text, null, NotificationCompat.PRIORITY_DEFAULT)
    }

    fun notifySmart(title: String, text: String) {
        push(CH_SMART, title, text, null, NotificationCompat.PRIORITY_LOW)
    }

    private fun push(channel: String, title: String, text: String, postId: String?, priority: Int) {
        val n = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF7C4DFF.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(priority)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(postId))
            .build()
        manager.notify((System.currentTimeMillis() % 10_000).toInt(), n)
    }
}

/** کارگر ساخت و ارسال خلاصه روزانه — ساعت ۱۷:۰۰ */
@HiltWorker
class DailyDigestWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val feed: FeedRepository,
    private val helper: NotificationHelper,
    private val prefs: Prefs
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val settings = prefs.settings.first()
        if (!settings.dailyDigest) return Result.success()
        val posts = feed.feed().first()
        if (posts.isEmpty()) return Result.retry()
        val digest = AiEngine.dailyDigest(posts)
        val body = digest.items.joinToString(" • ") { it.second }
        helper.notifyDigest(
            "خلاصه روزانه شما آماده است ✨",
            "${digest.totalAnalyzed} خبر تحلیل شد — $body"
        )
        return Result.success()
    }

    companion object {
        const val WORK_NAME = "daily_digest_17"

        /** زمان‌بندی روزانه ساعت ۱۷:۰۰ به وقت محلی */
        fun schedule(context: Context) {
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 17)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
            }
            val initialDelay = target.timeInMillis - now.timeInMillis
            val request = PeriodicWorkRequestBuilder<DailyDigestWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request
            )
        }
    }
}

/** کارگر بررسی فوری اخبار (هر ۳ ساعت) — اگر خبر با اهمیت «فوری» پیدا شد اعلان می‌دهد */
@HiltWorker
class InstantCheckWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val feed: FeedRepository,
    private val helper: NotificationHelper,
    private val prefs: Prefs
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        if (!prefs.settings.first().breaking) return Result.success()
        feed.refresh()              // سینک شبیه‌سازی‌شده
        val breaking = feed.feed().first()
            .filter { it.importance >= 85 }
            .maxByOrNull { it.publishedAt }
        breaking?.let { helper.notifyBreaking("⚡ فوری | ${it.channelName}", it.title, it.id) }
        return Result.success()
    }

    companion object {
        const val WORK_NAME = "instant_check"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<InstantCheckWorker>(3, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .setRequiresBatteryNotLow(true).build())
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request
            )
        }
    }
}

/** سرویس FCM — دریافت push از سرور (نیاز به google-services.json دارد) */
class NewsFlowFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: return
        val body = message.notification?.body ?: message.data["body"] ?: ""
        val type = message.data["type"] ?: "breaking"
        val helper = NotificationHelper(applicationContext)
        when (type) {
            "digest" -> helper.notifyDigest(title, body)
            "smart" -> helper.notifySmart(title, body)
            else -> helper.notifyBreaking(title, body, message.data["postId"])
        }
    }

    override fun onNewToken(token: String) {
        // در نسخه محصول: توکن به سرور ارسال می‌شود
    }
}
