package ir.newsflow.ai.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.newsflow.ai.core.Post
import ir.newsflow.ai.core.repo.FeedRepository
import ir.newsflow.ai.ui.components.NewsCard
import ir.newsflow.ai.ui.theme.BrandCyan
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SavedViewModel @Inject constructor(private val feed: FeedRepository) : ViewModel() {
    val saved: StateFlow<List<Post>> = feed.feed()
        .map { list -> list.filter { it.isSaved } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleSave(id: String) = viewModelScope.launch { feed.toggleSave(id) }
    fun react(id: String, type: ir.newsflow.ai.core.ReactionType?) =
        viewModelScope.launch { feed.react(id, type) }
}

@Composable
fun SavedScreen(onOpenPost: (String) -> Unit, vm: SavedViewModel = hiltViewModel()) {
    val saved by vm.saved.collectAsState()
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Text("ذخیره‌شده‌ها 🔖", style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp))

        if (saved.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Bookmark, null, tint = BrandCyan.copy(.4f),
                        modifier = Modifier.size(72.dp))
                    Spacer(Modifier.height(14.dp))
                    Text("هنوز خبری ذخیره نکرده‌اید",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("کارت‌ها را با دکمه 🔖 برای مطالعه بعدی نگه دارید",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            return@Column
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 100.dp)) {
            items(saved, key = { it.id }) { post ->
                NewsCard(
                    post = post,
                    onOpen = { onOpenPost(post.id) },
                    onSave = { vm.toggleSave(post.id) },
                    onReact = { vm.react(post.id, it) },
                    onShare = { sharePost(ctx, post.title, post.channelName) },
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                )
            }
        }
    }
}
