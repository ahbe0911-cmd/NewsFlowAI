package ir.newsflow.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.newsflow.ai.core.Post
import ir.newsflow.ai.core.repo.FeedRepository
import ir.newsflow.ai.data.ai.AiEngine.compactFa
import ir.newsflow.ai.data.ai.AiEngine.toFa
import ir.newsflow.ai.ui.components.*
import ir.newsflow.ai.ui.theme.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

data class DiscoverUi(
    val query: String = "",
    val results: List<Post>? = null,     // null = حالت اکسپلور عادی
    val trending: List<Pair<String, Int>> = emptyList(),
    val hot: List<Post> = emptyList(),
    val forYou: List<Post> = emptyList(),
    val all: List<Post> = emptyList()
)

@HiltViewModel
class DiscoverViewModel @Inject constructor(private val feed: FeedRepository) : ViewModel() {
    private val query = MutableStateFlow("")

    val ui: StateFlow<DiscoverUi> = combine(
        query, feed.trendingTopics(), feed.hotToday(5), feed.suggestedForYou(2), feed.feed()
    ) { q, trending, hot, forYou, all ->
        DiscoverUi(
            query = q,
            results = if (q.isBlank()) null else all.filter {
                it.title.contains(q) || it.body.contains(q) || it.channelName.contains(q)
            },
            trending = trending, hot = hot, forYou = forYou, all = all
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DiscoverUi())

    fun onQuery(v: String) { query.value = v }
}

@Composable
fun DiscoverScreen(onOpenPost: (String) -> Unit, vm: DiscoverViewModel = hiltViewModel()) {
    val ui by vm.ui.collectAsState()
    LazyColumn(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        /* جست‌وجو */
        item {
            OutlinedTextField(
                value = ui.query, onValueChange = vm::onQuery,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
                placeholder = { Text("جست‌وجوی خبر، کانال یا موضوع…") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(26.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrandCyan,
                    unfocusedBorderColor = Color.White.copy(alpha = .12f)
                )
            )
        }

        val results = ui.results
        if (results != null) {
            item { SectionTitle("${results.size.toFa()} نتیجه برای «${ui.query}»") }
            items(results, key = { "r_" + it.id }) { post ->
                NewsCard(
                    post = post, onOpen = { onOpenPost(post.id) },
                    onSave = {}, onReact = {}, onShare = {}, showAiBox = false,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                )
            }
            return@LazyColumn
        }

        /* موضوعات ترند */
        item { SectionTitle("🔥 موضوعات ترند امروز") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), reverseLayout = true) {
                items(ui.trending) { (word, count) ->
                    Surface(
                        color = BrandViolet.copy(alpha = .16f),
                        shape = RoundedCornerShape(50),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp, Brush.linearGradient(listOf(BrandViolet.copy(.6f), BrandCyan.copy(.6f)))
                        ),
                        modifier = Modifier.padding(horizontal = 4.dp).clickable { vm.onQuery(word) }
                    ) {
                        Text("#$word · ${count.toFa()}",
                            style = MaterialTheme.typography.labelLarge, color = Color(0xFFC7B6FF),
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
                    }
                }
            }
        }

        /* پیشنهاد برای شما — کاروسل بزرگ */
        item { SectionTitle("✨ پیشنهاد هوشمند برای شما") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), reverseLayout = true) {
                items(ui.forYou, key = { "fy_" + it.id }) { post ->
                    ForYouCard(post) { onOpenPost(post.id) }
                }
            }
        }

        /* داغ‌ترین‌ها با رتبه */
        item { SectionTitle("🚀 داغ‌ترین‌های امروز") }
        items(ui.hot.size) { i ->
            val post = ui.hot[i]
            HotRankRow(rank = i + 1, post = post) { onOpenPost(post.id) }
        }
    }
}

@Composable
private fun ForYouCard(post: Post, onClick: () -> Unit) {
    Box(
        Modifier.padding(horizontal = 6.dp).width(240.dp).height(300.dp)
            .clip(RoundedCornerShape(22.dp)).clickable(onClick = onClick)
    ) {
        if (post.imageRes.isNotEmpty())
            CoverImage(post.imageRes, Modifier.fillMaxSize(), corner = 22.dp)
        else Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF3B2E7A), Color(0xFF0E5A66)))))
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, Color(0xE605070D)), startY = 300f))
        )
        Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
            ImportanceBadge(post.importanceLevel, post.importance)
            Spacer(Modifier.height(8.dp))
            Text(post.title, style = MaterialTheme.typography.titleSmall, color = Color.White,
                maxLines = 3, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Text("${post.channelName} · ❤ ${compactFa(post.likeCount)}",
                style = MaterialTheme.typography.labelSmall, color = Color(0xFFB9C2E0))
        }
    }
}

@Composable
private fun HotRankRow(rank: Int, post: Post, onClick: () -> Unit) {
    GlassCard(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)
            .clickable(onClick = onClick),
        contentPadding = PaddingValues(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                rank.toFa(),
                style = MaterialTheme.typography.headlineSmall, color = BrandAmber,
                modifier = Modifier.width(36.dp)
            )
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text(post.title, style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${post.channelName} · ${timeAgoFa(post.publishedAt)} · ❤ ${compactFa(post.likeCount)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (post.imageRes.isNotEmpty())
                CoverImage(post.imageRes, Modifier.size(64.dp), corner = 12.dp)
        }
    }
}
