package ir.newsflow.ai.ui.screens

import android.content.Intent
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.newsflow.ai.core.*
import ir.newsflow.ai.core.repo.ChannelRepository
import ir.newsflow.ai.core.repo.FeedRepository
import ir.newsflow.ai.data.Prefs
import ir.newsflow.ai.ui.components.ChannelAvatar
import ir.newsflow.ai.ui.components.NewsCard
import ir.newsflow.ai.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUi(
    val posts: List<Post> = emptyList(),
    val channels: List<Channel> = emptyList(),
    val selectedCategory: NewsCategory = NewsCategory.ALL,
    val refreshing: Boolean = false,
    val userName: String = "",
    val autoSummary: Boolean = true,
    val snackbar: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val feed: FeedRepository,
    private val channelsRepo: ChannelRepository,
    private val prefs: Prefs
) : ViewModel() {

    private val _category = MutableStateFlow(NewsCategory.ALL)
    private val _refreshing = MutableStateFlow(false)
    private val _snack = MutableStateFlow<String?>(null)

    val ui: StateFlow<HomeUi> = combine(
        _category, feed.feed(), channelsRepo.followed(), prefs.settings
    ) { cat, _, chans, settings -> // feed(personal) — ساده‌سازی: فیلتر دسته در اینجا
        Triple(cat, chans, settings)
    }.flatMapLatest { (cat, chans, settings) ->
        feed.feed(cat).map { posts -> HomeUi(
            posts = posts, channels = chans, selectedCategory = cat,
            userName = settings.userName, autoSummary = settings.autoSummary,
            refreshing = false, snackbar = _snack.value
        ) }
    }.combine(_refreshing) { ui, r -> ui.copy(refreshing = r) }
        .combine(_snack) { ui, s -> ui.copy(snackbar = s) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUi())

    fun selectCategory(c: NewsCategory) { _category.value = c }

    fun refresh() = viewModelScope.launch {
        _refreshing.value = true
        val result = feed.refresh()
        _refreshing.value = false
        _snack.value = result.fold(
            onSuccess = { if (it > 0) "$it خبر جدید دریافت شد ✨" else "فید شما به‌روز است" },
            onFailure = { "خطا در به‌روزرسانی!" }
        )
        delay(2500); _snack.value = null
    }

    fun toggleSave(id: String) = viewModelScope.launch { feed.toggleSave(id) }
    fun react(id: String, type: ReactionType?) = viewModelScope.launch { feed.react(id, type) }
    fun follow(id: String) = viewModelScope.launch { channelsRepo.follow(id, true) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenPost: (String) -> Unit,
    onOpenAssistant: () -> Unit,
    onOpenSettings: () -> Unit,
    vm: HomeViewModel = hiltViewModel()
) {
    val ui by vm.ui.collectAsState()
    val ctx = LocalContext.current
    val snackbarHost = remember { SnackbarHostState() }

    LaunchedEffect(ui.snackbar) { ui.snackbar?.let { snackbarHost.showSnackbar(it) } }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PullToRefreshBox(
            isRefreshing = ui.refreshing,
            onRefresh = { vm.refresh() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                /* سلام شخصی‌سازی‌شده */
                item(key = "greet") {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onOpenSettings) {
                            Icon(Icons.Outlined.Settings, "تنظیمات", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                if (ui.userName.isNotBlank()) "سلام ${ui.userName} 👋" else "نیوزفلو AI",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text("جریان خبری امروز شما آماده است",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.width(12.dp))
                        Box {
                            IconButton(onClick = { /* عدد اعلان دمویی */ }) {
                                Icon(Icons.Filled.Notifications, "اعلان", tint = MaterialTheme.colorScheme.onBackground)
                            }
                            Box(
                                Modifier.align(Alignment.TopStart).size(16.dp).clip(CircleShape)
                                    .background(BrandPink),
                                contentAlignment = Alignment.Center
                            ) { Text("۳", style = MaterialTheme.typography.labelSmall, color = Color.White) }
                        }
                    }
                }

                /* ردیف کانال‌ها (استایل استوری) */
                item(key = "channels_row") {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        reverseLayout = true
                    ) {
                        items(ui.channels, key = { "row_" + it.id }) { ch ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            ) {
                                ChannelAvatar(ch.name, ch.avatarSeed, size = 58.dp, ring = true)
                                Spacer(Modifier.height(6.dp))
                                Text(ch.name, style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                /* دسته‌بندی‌ها */
                item(key = "cats") {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        reverseLayout = true
                    ) {
                        items(NewsCategory.entries.toList()) { cat ->
                            FilterChip(
                                selected = ui.selectedCategory == cat,
                                onClick = { vm.selectCategory(cat) },
                                label = { Text("${cat.emoji} ${cat.fa}") },
                                modifier = Modifier.padding(horizontal = 4.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BrandViolet.copy(alpha = .32f),
                                    selectedLabelColor = Color(0xFFC7B6FF)
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true, selected = ui.selectedCategory == cat,
                                    borderColor = Color.White.copy(alpha = .12f),
                                    selectedBorderColor = BrandViolet
                                )
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                /* فید */
                items(ui.posts, key = { it.id }) { post ->
                    NewsCard(
                        post = post,
                        onOpen = { onOpenPost(post.id) },
                        onSave = { vm.toggleSave(post.id) },
                        onReact = { t -> vm.react(post.id, t) },
                        onShare = {
                            sharePost(ctx, post.title, post.channelName)
                        },
                        showAiBox = ui.autoSummary,
                        modifier = Modifier
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                            .animateItem(fadeInSpec = tween(280), fadeOutSpec = tween(200))
                    )
                }
            }
        }

        /* دکمه دستیار AI — شناور */
        ExtendedFloatingActionButton(
            onClick = onOpenAssistant,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 18.dp, bottom = 18.dp),
            containerColor = BrandViolet,
            contentColor = Color.White,
            icon = { Icon(Icons.Filled.AutoAwesome, "AI") },
            text = { Text("دستیار هوشمند") }
        )

        SnackbarHost(snackbarHost, Modifier.align(Alignment.TopCenter))
    }
}

fun sharePost(context: android.content.Context, title: String, channel: String) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "📰 $title\n— از ${channel} در «نیوزفلو AI»\nhttps://newsflow.ir/app")
    }
    context.startActivity(Intent.createChooser(i, "اشتراک‌گذاری خبر"))
}
