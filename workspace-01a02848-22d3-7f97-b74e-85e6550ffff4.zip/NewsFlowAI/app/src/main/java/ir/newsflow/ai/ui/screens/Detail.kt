package ir.newsflow.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.newsflow.ai.core.Post
import ir.newsflow.ai.core.ReactionType
import ir.newsflow.ai.core.repo.FeedRepository
import ir.newsflow.ai.ui.components.*
import ir.newsflow.ai.ui.theme.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DetailUi(
    val post: Post? = null,
    val related: List<Post> = emptyList()
)

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val feed: FeedRepository,
    savedState: SavedStateHandle
) : ViewModel() {
    private val postId: String = savedState.get<String>("postId") ?: ""

    val ui: StateFlow<DetailUi> = feed.feed().combine(feed.postById(postId)) { all, post ->
        post?.let { p -> DetailUi(p, ir.newsflow.ai.data.ai.AiEngine.related(p, all)) } ?: DetailUi()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DetailUi())

    init { viewModelScope.launch { feed.markRead(postId) } }

    fun toggleSave() = viewModelScope.launch { feed.toggleSave(postId) }
    fun react(t: ReactionType?) = viewModelScope.launch { feed.react(postId, t) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsDetailScreen(
    postId: String, onBack: () -> Unit, onOpenPost: (String) -> Unit,
    vm: DetailViewModel = hiltViewModel()
) {
    val ui by vm.ui.collectAsState()
    val ctx = LocalContext.current
    val post = ui.post

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(post?.channelName ?: "خبر", style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, "بازگشت")
                    }
                },
                actions = {
                    IconButton(onClick = { post?.let { vm.toggleSave() } }) {
                        Icon(
                            if (post?.isSaved == true) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                            "ذخیره",
                            tint = if (post?.isSaved == true) BrandCyan else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = {
                        post?.let { sharePost(ctx, it.title, it.channelName) }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.Send, "اشتراک", tint = MaterialTheme.colorScheme.onSurface)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        if (post == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = BrandCyan)
            }
            return@Scaffold
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(bottom = 60.dp)
        ) {
            item {
                Column(Modifier.padding(horizontal = 20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ImportanceBadge(post.importanceLevel, post.importance)
                        Spacer(Modifier.weight(1f))
                        Text(timeAgoFa(post.publishedAt), style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(post.title, style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onBackground)
                    Spacer(Modifier.height(12.dp))
                }
            }

            if (post.imageRes.isNotEmpty()) {
                item {
                    CoverImage(post.imageRes,
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(230.dp),
                        corner = 22.dp)
                }
            }

            /* متر اهمیت + جعبه AI */
            item {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                    ImportanceMeter(post.importance)
                    Spacer(Modifier.height(14.dp))
                    AiSummaryBox(post.aiBullets)
                }
            }

            /* متن کامل */
            item {
                Text(
                    post.body, style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
            }

            /* منابع */
            if (post.sources.isNotEmpty()) {
                item {
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                        Text("منابع", style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(6.dp))
                        Row {
                            post.sources.take(3).forEach {
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(50),
                                    modifier = Modifier.padding(start = 6.dp)
                                ) {
                                    Text(it, style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                                }
                            }
                        }
                    }
                }
            }

            /* نوار واکنش */
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    ReactionBar(
                        post = post, onOpen = {}, onSave = { vm.toggleSave() },
                        onReact = { vm.react(it) },
                        onShare = { sharePost(ctx, post.title, post.channelName) },
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )
                }
            }

            /* کانال منتشرکننده */
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
                    contentPadding = PaddingValues(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { /* دنبال‌کردن در هاب */ }) {
                            Text("مشاهده در هاب", style = MaterialTheme.typography.labelLarge, color = BrandCyan)
                        }
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(post.channelName, style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface)
                                if (post.channelVerified) {
                                    Spacer(Modifier.width(4.dp))
                                    Icon(Icons.Filled.Verified, null, tint = BrandCyan, modifier = Modifier.size(15.dp))
                                }
                            }
                            Text("کانال منتشرکننده خبر", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.width(12.dp))
                        ChannelAvatar(post.channelName, post.channelId.hashCode().toLong(), size = 46.dp)
                    }
                }
            }

            /* اخبار مرتبط */
            if (ui.related.isNotEmpty()) {
                item { SectionTitle("🔗 اخبار مرتبط (یافت‌شده با AI)") }
                items(ui.related, key = { "rel_" + it.id }) { rel ->
                    GlassCard(
                        modifier = Modifier.fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 5.dp)
                            .clickable { onOpenPost(rel.id) },
                        contentPadding = PaddingValues(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                                Text(rel.title, style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("${rel.channelName} · ${timeAgoFa(rel.publishedAt)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (rel.imageRes.isNotEmpty())
                                CoverImage(rel.imageRes, Modifier.size(72.dp), corner = 12.dp)
                        }
                    }
                }
            }
        }
    }
}
