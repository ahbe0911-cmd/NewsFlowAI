package ir.newsflow.ai.core

/** دسته‌بندی‌های خبری نیوزفلو */
enum class NewsCategory(val fa: String, val emoji: String) {
    ALL("همه", "🌐"),
    TECH("فناوری", "💻"),
    AI("هوش مصنوعی", "🤖"),
    ECONOMY("اقتصاد", "📈"),
    SPORT("ورزش", "🏅"),
    SCIENCE("علم", "🔭"),
    CULTURE("فرهنگ", "🎨");

    companion object {
        fun fromKey(key: String): NewsCategory = entries.firstOrNull { it.name == key } ?: ALL
    }
}

/** سطح اهمیت خبر که توسط موتور AI محاسبه می‌شود */
enum class Importance(val fa: String, val threshold: Int) {
    BREAKING("فوری", 85),
    HIGH("مهم", 65),
    NORMAL("معمولی", 0);

    companion object {
        fun of(score: Int) = when {
            score >= BREAKING.threshold -> BREAKING
            score >= HIGH.threshold -> HIGH
            else -> NORMAL
        }
    }
}

enum class ReactionType(val emoji: String) { LIKE("❤"), FIRE("🔥"), WOW("😮"), SAD("😢") }

data class Channel(
    val id: String,
    val name: String,
    val username: String,        // @telegram
    val category: NewsCategory,
    val followers: Long,
    val verified: Boolean = false,
    val avatarSeed: Long,
    val isFollowed: Boolean = false,
    val isSuggested: Boolean = false
)

data class Post(
    val id: String,
    val channelId: String,
    val channelName: String,
    val channelVerified: Boolean,
    val title: String,
    val body: String,
    val imageRes: String,          // نام drawable باندل‌شده (خالی = بدون تصویر)
    val category: NewsCategory,
    val publishedAt: Long,         // epoch millis
    val importance: Int,           // 0..100 محاسبه‌شده با AI
    val aiBullets: List<String>,   // نکات کلیدی استخراج‌شده AI
    val likeCount: Int,
    val savesCount: Int,
    val viewsCount: Int,
    val myReaction: ReactionType? = null,
    val isSaved: Boolean = false,
    val sources: List<String> = emptyList()
) {
    val importanceLevel get() = Importance.of(importance)
}

/** پیام‌های دستیار هوشمند */
data class AssistantMessage(
    val id: Long,
    val fromAi: Boolean,
    val text: String,
    val bullets: List<String> = emptyList(),
    val digestCard: DigestCard? = null
)

data class DigestCard(
    val title: String,
    val totalAnalyzed: Int,
    val items: List<Pair<Importance, String>>,
    val connectionHint: String
)

data class UserProfile(
    val name: String,
    val joinedYear: String,
    val readCount: Int,
    val savedCount: Int,
    val followingCount: Int,
    val interestsShare: List<Pair<NewsCategory, Int>>
)
