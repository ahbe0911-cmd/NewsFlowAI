package ir.newsflow.ai.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "newsflow_settings")

/** حالت تم */
enum class ThemeMode { SYSTEM, LIGHT, DARK }

/**
 * تنظیمات کاربر — DataStore (Repository الگوی Preferences)
 */
class Prefs(private val context: Context) {

    companion object {
        val KEY_THEME = stringPreferencesKey("theme_mode")
        val KEY_FONT_SCALE = floatPreferencesKey("font_scale")
        val KEY_BREAKING = booleanPreferencesKey("notif_breaking")
        val KEY_DIGEST = booleanPreferencesKey("notif_digest")
        val KEY_SMART = booleanPreferencesKey("notif_smart")
        val KEY_AUTO_SUMMARY = booleanPreferencesKey("ai_auto_summary")
        val KEY_PERSONALIZE = booleanPreferencesKey("ai_personalize")
        val KEY_INTERESTS = stringSetPreferencesKey("interests")
        val KEY_USER_NAME = stringPreferencesKey("user_name")
        val KEY_ONBOARDED = booleanPreferencesKey("onboarded")
    }

    data class Settings(
        val themeMode: ThemeMode = ThemeMode.DARK,
        val fontScale: Float = 1f,
        val breaking: Boolean = true,
        val dailyDigest: Boolean = true,
        val smartSuggest: Boolean = true,
        val autoSummary: Boolean = true,
        val personalize: Boolean = true,
        val interests: Set<String> = setOf("TECH", "AI"),
        val userName: String = "",
        val onboarded: Boolean = false
    )

    val settings: Flow<Settings> = context.dataStore.data.map { p ->
        Settings(
            themeMode = runCatching { ThemeMode.valueOf(p[KEY_THEME] ?: "DARK") }
                .getOrDefault(ThemeMode.DARK),
            fontScale = p[KEY_FONT_SCALE] ?: 1f,
            breaking = p[KEY_BREAKING] ?: true,
            dailyDigest = p[KEY_DIGEST] ?: true,
            smartSuggest = p[KEY_SMART] ?: true,
            autoSummary = p[KEY_AUTO_SUMMARY] ?: true,
            personalize = p[KEY_PERSONALIZE] ?: true,
            interests = p[KEY_INTERESTS] ?: setOf("TECH", "AI"),
            userName = p[KEY_USER_NAME] ?: "",
            onboarded = p[KEY_ONBOARDED] ?: false
        )
    }

    suspend fun setTheme(mode: ThemeMode) = context.dataStore.edit { it[KEY_THEME] = mode.name }
    suspend fun setFontScale(v: Float) = context.dataStore.edit { it[KEY_FONT_SCALE] = v }
    suspend fun setBreaking(v: Boolean) = context.dataStore.edit { it[KEY_BREAKING] = v }
    suspend fun setDigest(v: Boolean) = context.dataStore.edit { it[KEY_DIGEST] = v }
    suspend fun setSmart(v: Boolean) = context.dataStore.edit { it[KEY_SMART] = v }
    suspend fun setAutoSummary(v: Boolean) = context.dataStore.edit { it[KEY_AUTO_SUMMARY] = v }
    suspend fun setPersonalize(v: Boolean) = context.dataStore.edit { it[KEY_PERSONALIZE] = v }
    suspend fun setInterests(v: Set<String>) = context.dataStore.edit { it[KEY_INTERESTS] = v }

    suspend fun login(name: String, interests: Set<String>) = context.dataStore.edit {
        it[KEY_USER_NAME] = name
        it[KEY_INTERESTS] = interests
        it[KEY_ONBOARDED] = true
    }
}
