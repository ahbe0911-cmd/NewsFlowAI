package ir.newsflow.ai.data.local

import android.content.Context
import androidx.room.*
import ir.newsflow.ai.core.NewsCategory
import ir.newsflow.ai.core.ReactionType
import kotlinx.coroutines.flow.Flow

/* ---------------------------------- Entities ---------------------------------- */

@Entity(tableName = "channels")
data class ChannelEntity(
    @PrimaryKey val id: String,
    val name: String,
    val username: String,
    val category: NewsCategory,
    val followers: Long,
    val verified: Boolean,
    val avatarSeed: Long,
    val isFollowed: Boolean,
    val isSuggested: Boolean
)

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey val id: String,
    val channelId: String,
    val title: String,
    val body: String,
    val imageRes: String,
    val category: NewsCategory,
    val publishedAt: Long,
    val importance: Int,
    val likeCount: Int,
    val savesCount: Int,
    val viewsCount: Int,
    val sources: List<String>           // Converters: json ساده با «|»
)

@Entity(tableName = "saved_posts")
data class SavedEntity(@PrimaryKey val postId: String, val savedAt: Long)

@Entity(tableName = "reactions", primaryKeys = ["postId"])
data class ReactionEntity(val postId: String, val type: ReactionType)

@Entity(tableName = "read_history")
data class ReadEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val postId: String,
    val category: NewsCategory,
    val readAt: Long,
    val dwellMs: Long = 20_000
)

/* ------------------------------------ DAOs ------------------------------------ */

@Dao
interface ChannelDao {
    @Query("SELECT * FROM channels ORDER BY followers DESC")
    fun observeAll(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE isFollowed = 1")
    fun observeFollowed(): Flow<List<ChannelEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<ChannelEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ChannelEntity)

    @Query("UPDATE channels SET isFollowed = :followed WHERE id = :id")
    suspend fun setFollowed(id: String, followed: Boolean)

    @Delete suspend fun delete(item: ChannelEntity)

    @Query("DELETE FROM channels WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT COUNT(*) FROM channels")
    suspend fun count(): Int
}

@Dao
interface PostDao {
    @Query("SELECT * FROM posts ORDER BY publishedAt DESC")
    fun observeAll(): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE id = :id")
    fun observeById(id: String): Flow<PostEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<PostEntity>)

    @Query("SELECT COUNT(*) FROM posts")
    suspend fun count(): Int

    @Query("UPDATE posts SET likeCount = likeCount + :delta WHERE id = :id")
    suspend fun bumpLikes(id: String, delta: Int)

    @Query("UPDATE posts SET savesCount = savesCount + :delta WHERE id = :id")
    suspend fun bumpSaves(id: String, delta: Int)
}

@Dao
interface SavedDao {
    @Query("SELECT postId FROM saved_posts")
    fun observeIds(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(entity: SavedEntity)

    @Query("DELETE FROM saved_posts WHERE postId = :postId")
    suspend fun remove(postId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM saved_posts WHERE postId = :postId)")
    fun observeIsSaved(postId: String): Flow<Boolean>

    @Query("SELECT COUNT(*) FROM saved_posts")
    fun observeCount(): Flow<Int>
}

@Dao
interface ReactionDao {
    @Query("SELECT * FROM reactions")
    fun observeAll(): Flow<List<ReactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun set(entity: ReactionEntity)

    @Query("DELETE FROM reactions WHERE postId = :postId")
    suspend fun clear(postId: String)
}

@Dao
interface ReadDao {
    @Insert suspend fun add(entity: ReadEntity)

    @Query("SELECT * FROM read_history ORDER BY readAt DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<ReadEntity>>

    @Query("SELECT category, COUNT(*) AS cnt FROM read_history GROUP BY category ORDER BY cnt DESC")
    fun observeCategoryCounts(): Flow<List<CategoryCount>>

    @Query("SELECT COUNT(*) FROM read_history")
    fun observeTotal(): Flow<Int>
}

data class CategoryCount(val category: NewsCategory, val cnt: Int)

/* ---------------------------------- Database ---------------------------------- */

class Converters {
    @TypeConverter fun listToString(v: List<String>): String = v.joinToString("|")
    @TypeConverter fun stringToList(v: String): List<String> =
        if (v.isBlank()) emptyList() else v.split("|")
    @TypeConverter fun catToString(v: NewsCategory): String = v.name
    @TypeConverter fun stringToCat(v: String): NewsCategory = NewsCategory.fromKey(v)
    @TypeConverter fun reactionToString(v: ReactionType): String = v.name
    @TypeConverter fun stringToReaction(v: String): ReactionType = ReactionType.valueOf(v)
}

@Database(
    entities = [ChannelEntity::class, PostEntity::class, SavedEntity::class,
        ReactionEntity::class, ReadEntity::class],
    version = 1, exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun channelDao(): ChannelDao
    abstract fun postDao(): PostDao
    abstract fun savedDao(): SavedDao
    abstract fun reactionDao(): ReactionDao
    abstract fun readDao(): ReadDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun build(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext, AppDatabase::class.java, "newsflow.db"
                ).build().also { instance = it }
            }
    }
}
