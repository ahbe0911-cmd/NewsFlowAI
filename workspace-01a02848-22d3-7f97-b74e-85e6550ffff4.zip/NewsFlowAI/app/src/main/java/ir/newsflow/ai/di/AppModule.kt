package ir.newsflow.ai.di

import android.content.Context
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import ir.newsflow.ai.core.repo.ChannelRepository
import ir.newsflow.ai.core.repo.FeedRepository
import ir.newsflow.ai.core.repo.ProfileRepository
import ir.newsflow.ai.data.Prefs
import ir.newsflow.ai.data.local.AppDatabase
import ir.newsflow.ai.data.repo.NewsRepositoryImpl
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDb(@ApplicationContext ctx: Context): AppDatabase = AppDatabase.build(ctx)

    @Provides @Singleton
    fun providePrefs(@ApplicationContext ctx: Context): Prefs = Prefs(ctx)

    @Provides @Singleton
    fun provideNotificationHelper(@ApplicationContext ctx: Context) =
        ir.newsflow.ai.notif.NotificationHelper(ctx)
}

/** اتصال اینترفیس‌های دامنه به پیاده‌سازی‌ها */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepoBinds {
    @Binds @Singleton abstract fun bindFeed(impl: NewsRepositoryImpl): FeedRepository
    @Binds @Singleton abstract fun bindChannel(impl: NewsRepositoryImpl): ChannelRepository
    @Binds @Singleton abstract fun bindProfile(impl: NewsRepositoryImpl): ProfileRepository
}
