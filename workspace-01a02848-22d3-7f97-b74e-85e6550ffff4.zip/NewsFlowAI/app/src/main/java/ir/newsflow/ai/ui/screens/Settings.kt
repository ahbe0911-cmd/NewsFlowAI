package ir.newsflow.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.newsflow.ai.core.NewsCategory
import ir.newsflow.ai.data.Prefs
import ir.newsflow.ai.data.ThemeMode
import ir.newsflow.ai.ui.components.GlassCard
import ir.newsflow.ai.ui.theme.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(private val prefs: Prefs) : ViewModel() {
    val settings: StateFlow<Prefs.Settings> = prefs.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Prefs.Settings())

    fun setTheme(m: ThemeMode) = viewModelScope.launch { prefs.setTheme(m) }
    fun setFont(v: Float) = viewModelScope.launch { prefs.setFontScale(v) }
    fun setBreaking(v: Boolean) = viewModelScope.launch { prefs.setBreaking(v) }
    fun setDigest(v: Boolean) = viewModelScope.launch { prefs.setDigest(v) }
    fun setSmart(v: Boolean) = viewModelScope.launch { prefs.setSmart(v) }
    fun setAutoSummary(v: Boolean) = viewModelScope.launch { prefs.setAutoSummary(v) }
    fun setPersonalize(v: Boolean) = viewModelScope.launch { prefs.setPersonalize(v) }
    fun toggleInterest(k: String) = viewModelScope.launch {
        val cur = settings.value.interests.toMutableSet()
        if (k in cur) cur.remove(k) else cur.add(k)
        prefs.setInterests(cur)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, vm: SettingsViewModel = hiltViewModel()) {
    val s by vm.settings.collectAsState()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("تنظیمات ⚙", style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "بازگشت") }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            /* ---------- ظاهر ---------- */
            item {
                SettingsHeader("🎨 ظاهر برنامه")
                GlassCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp)) {
                    Row(
                        Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row {
                            ThemeMode.entries.forEach { m ->
                                val label = when (m) { ThemeMode.DARK -> "تاریک"; ThemeMode.LIGHT -> "روشن"; ThemeMode.SYSTEM -> "خودکار" }
                                FilterChip(
                                    selected = s.themeMode == m,
                                    onClick = { vm.setTheme(m) },
                                    label = { Text(label) },
                                    modifier = Modifier.padding(horizontal = 3.dp)
                                )
                            }
                        }
                        Text("حالت نمایش", style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface)
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(
                        Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(when {
                            s.fontScale <= .93f -> "کوچک"
                            s.fontScale >= 1.07f -> "بزرگ"
                            else -> "استاندارد"
                        }, style = MaterialTheme.typography.labelLarge, color = BrandCyan)
                        Text("اندازه فونت اخبار", style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface)
                    }
                    Slider(
                        value = s.fontScale, onValueChange = vm::setFont,
                        valueRange = 0.85f..1.2f, steps = 6
                    )
                    Text("متن نمونه: نیوزفلو AI اخبار را با فونت وزیر نمایش می‌دهد.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            /* ---------- اعلان‌ها ---------- */
            item {
                SettingsHeader("🔔 اعلان‌ها")
                GlassCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(6.dp)) {
                    SettingSwitch("اخبار فوری (Breaking)", "اعلان فوری وقتی AI خبر حیاتی تشخیص دهد",
                        s.breaking, vm::setBreaking)
                    HorizontalDividerMod()
                    SettingSwitch("خلاصه روزانه — ساعت ۱۷:۰۰", "هر روز عصر، خبرهای مهم روز برسد",
                        s.dailyDigest, vm::setDigest)
                    HorizontalDividerMod()
                    SettingSwitch("پیشنهاد هوشمند", "اعلان محتوای پیشنهادی بر اساس سلیقه شما",
                        s.smartSuggest, vm::setSmart)
                }
            }

            /* ---------- هوش مصنوعی ---------- */
            item {
                SettingsHeader("✨ هوش مصنوعی")
                GlassCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(6.dp)) {
                    SettingSwitch("خلاصه‌سازی خودکار کارت‌ها", "نمایش نکات کلیدی AI روی هر کارت",
                        s.autoSummary, vm::setAutoSummary)
                    HorizontalDividerMod()
                    SettingSwitch("شخصی‌سازی فید بر اساس رفتار", "ترتیب خبرها از روی الگوی خوانش شما",
                        s.personalize, vm::setPersonalize)
                    Spacer(Modifier.height(6.dp))
                    Surface(
                        color = SuccessGreen.copy(alpha = .12f),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().padding(8.dp)
                    ) {
                        Text(
                            "🔒 پردازش روی دستگاه — داده‌های خوانش شما هرگز از گوشی خارج نمی‌شود.",
                            style = MaterialTheme.typography.bodySmall, color = SuccessGreen,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            /* ---------- علایق ---------- */
            item {
                SettingsHeader("🎯 علایق خبری")
                GlassCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(14.dp)) {
                    FlowRowSimple {
                        NewsCategory.entries.filter { it != NewsCategory.ALL }.forEach { cat ->
                            FilterChip(
                                selected = cat.name in s.interests,
                                onClick = { vm.toggleInterest(cat.name) },
                                label = { Text("${cat.emoji} ${cat.fa}") },
                                modifier = Modifier.padding(horizontal = 3.dp)
                            )
                        }
                    }
                }
            }

            /* ---------- مدیریت کانال‌ها ---------- */
            item {
                SettingsHeader("📡 محتوا")
                GlassCard(
                    Modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp)
                ) {
                    Text("کانال‌ها و منابع خبری را از صفحه «هاب کانال‌ها» مدیریت کنید؛ افزودن کانال تلگرام، حذف و دسته‌بندی موضوعی.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(28.dp))
                Text(
                    "NewsFlow AI · نسخه ۱٫۰٫۰\nشبکه اجتماعی خبری هوشمند",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun SettingsHeader(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = BrandCyan,
        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp))
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Switch(checked = checked, onCheckedChange = onChange)
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(title, style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.End)
            Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.End)
        }
    }
}

@Composable
private fun HorizontalDividerMod() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 10.dp),
        color = Color.White.copy(alpha = .06f)
    )
}
