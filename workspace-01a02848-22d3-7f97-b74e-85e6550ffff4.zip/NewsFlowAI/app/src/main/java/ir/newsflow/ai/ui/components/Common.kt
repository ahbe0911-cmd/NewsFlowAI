package ir.newsflow.ai.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import ir.newsflow.ai.R
import ir.newsflow.ai.core.Importance
import ir.newsflow.ai.data.ai.AiEngine.toFa
import ir.newsflow.ai.ui.theme.*

/* ------------------------- تصاویر باندل‌شده ------------------------- */
fun coverResId(context: android.content.Context, name: String): Int = when (name) {
    "news_tech" -> R.drawable.news_tech
    "news_ai" -> R.drawable.news_ai
    "news_econ" -> R.drawable.news_econ
    "news_sport" -> R.drawable.news_sport
    "news_science" -> R.drawable.news_science
    "feature_graphic" -> R.drawable.feature_graphic
    else -> 0
}

@Composable
fun CoverImage(name: String, modifier: Modifier = Modifier, corner: Dp = 16.dp) {
    val ctx = LocalContext.current
    val res = remember(name) { coverResId(ctx, name) }
    val shape = RoundedCornerShape(corner)
    if (res != 0) {
        Image(
            painter = rememberAsyncImagePainter(ImageRequest.Builder(ctx).data(res).crossfade(true).build()),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier.clip(shape)
        )
    } else {
        // جایگزین گرادیانی برای خبرهای بدون عکس
        Box(
            modifier
                .clip(shape)
                .background(Brush.linearGradient(listOf(Color(0xFF2A2050), Color(0xFF0E5A66))))
        ) {
            Icon(
                Icons.Filled.AutoAwesome, null,
                tint = Color.White.copy(alpha = .35f),
                modifier = Modifier.align(Alignment.Center).size(36.dp)
            )
        }
    }
}

/* ------------------------- آواتار کانال (حروف اول + رنگ از seed) ------------------------- */
private val avatarPalette = listOf(
    0xFF2E3A8C, 0xFF7A3E2E, 0xFF1F6B3A, 0xFF6B2E5A, 0xFF8C5E1F, 0xFF1F4E8C, 0xFF63388C, 0xFF8C2E4A
)

@Composable
fun ChannelAvatar(name: String, seed: Long, size: Dp = 44.dp, ring: Boolean = false) {
    val color = Color(avatarPalette[(seed % avatarPalette.size).toInt().let { if (it < 0) -it else it }])
    val initial = name.split(" ").filter { it.isNotBlank() }.take(2)
        .joinToString("") { it.take(2) }
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .then(if (ring) Modifier.border(2.dp, BrandGradient, CircleShape) else Modifier)
            .background(color),
        contentAlignment = Alignment.Center
    ) {
        Text(initial, color = Color.White, style = MaterialTheme.typography.labelLarge,
            textAlign = TextAlign.Center, maxLines = 1)
    }
}

/* ------------------------- نشان اهمیت ------------------------- */
@Composable
fun ImportanceBadge(level: Importance, score: Int) {
    val (bg, fg, label) = when (level) {
        Importance.BREAKING -> Triple(BrandPink, Color.White, "فوری ⚡")
        Importance.HIGH -> Triple(BrandAmber, Color(0xFF1A1200), "مهم ${score.toFa()}٪")
        Importance.NORMAL -> return
    }
    Surface(color = bg, shape = RoundedCornerShape(50)) {
        Text(label, color = fg, style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
    }
}

/* ------------------------- نوار متر اهمیت ------------------------- */
@Composable
fun ImportanceMeter(score: Int, modifier: Modifier = Modifier) {
    Column(modifier) {
        Row(
            Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("میزان اهمیت خبر", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${score.toFa()}٪", style = MaterialTheme.typography.labelLarge,
                color = when (Importance.of(score)) {
                    Importance.BREAKING -> BrandPink; Importance.HIGH -> BrandAmber; else -> BrandCyan
                })
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = .08f))
        ) {
            Box(
                Modifier.fillMaxWidth(score / 100f).fillMaxHeight()
                    .clip(RoundedCornerShape(50)).background(BrandGradient)
            )
        }
    }
}

/* ------------------------- جعبه خلاصه AI ------------------------- */
@Composable
fun AiSummaryBox(
    bullets: List<String>,
    modifier: Modifier = Modifier,
    header: String = "خلاصه هوش مصنوعی ⚡"
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(BrandGradientSoft)
            .border(1.dp, BrandViolet.copy(alpha = .4f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.AutoAwesome, null, tint = BrandCyan, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(header, style = MaterialTheme.typography.titleSmall, color = Color(0xFFC7B6FF))
        }
        Spacer(Modifier.height(10.dp))
        bullets.take(3).forEach {
            Row(Modifier.fillMaxWidth()) {
                Text("•", color = BrandCyan, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.width(6.dp))
                Text(it, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface)
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

/* ------------------------- عنوان بخش‌ها ------------------------- */
@Composable
fun SectionTitle(text: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
        if (action != null) TextButton(onClick = { onAction?.invoke() }) {
            Text(action, style = MaterialTheme.typography.labelLarge, color = BrandCyan)
        }
    }
}

/* ------------------------- سطح گلس (Glassmorphism) ------------------------- */
@Composable
fun GlassCard(modifier: Modifier = Modifier, contentPadding: PaddingValues = PaddingValues(0.dp),
              content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier, shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .72f),
        tonalElevation = 2.dp,
        border = BorderStroke(1.dp, Color.White.copy(alpha = .07f)),
        shadowElevation = 10.dp
    ) {
        Column(Modifier.padding(contentPadding), content = content)
    }
}
