package ir.newsflow.ai

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

/**
 * NewsFlow AI — نقطه شروع اپلیکیشن
 * Hilt برای DI + WorkManager با تزریق وابستگی (HiltWorker)
 */
@HiltAndroidApp
class NewsFlowApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()
}
