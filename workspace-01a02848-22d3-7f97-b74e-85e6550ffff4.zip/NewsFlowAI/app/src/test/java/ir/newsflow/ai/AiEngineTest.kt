package ir.newsflow.ai

import ir.newsflow.ai.core.Importance
import ir.newsflow.ai.core.NewsCategory
import ir.newsflow.ai.core.Post
import ir.newsflow.ai.data.ai.AiEngine
import org.junit.Assert.*
import org.junit.Test

/**
 * تست‌های واحد موتور AI — هسته محصول
 * اجرا: ./gradlew testDebugUnitTest
 */
class AiEngineTest {

    private val body = "شرکت بزرگ فناوری دیروز مدل جدید ترجمه فارسی را معرفی کرد. " +
            "این مدل دقت ترجمه را به ۹۴ درصد رسانده است. " +
            "کارشناسان معتقدند هوش مصنوعی وارد عصر تازه‌ای شده و خبررسانی فارسی متحول می‌شود. " +
            "نسخه آزمایشی پاییز عرضه می‌شود."

    @Test fun `summarize returns non-empty shorter text`() {
        val s = AiEngine.summarize("ترجمه فارسی", body)
        assertTrue(s.isNotBlank())
        assertTrue(s.length < body.length + 10)
    }

    @Test fun `keyPoints extracts up to 3 bullets`() {
        val pts = AiEngine.keyPoints("عنوان فوری", body)
        assertTrue(pts.size in 1..3)
        assertTrue(pts.all { it.isNotBlank() })
    }

    @Test fun `breaking keywords raise importance`() {
        val now = System.currentTimeMillis()
        val calm = AiEngine.importanceScore("گزارش هفتگی بازار", body, now, now)
        val urgent = AiEngine.importanceScore("فوری: رکورد تاریخی شکست", "$body هشدار رسمی", now, now)
        assertTrue(urgent > calm)
        assertTrue(urgent in 0..100)
    }

    @Test fun `old news gets lower freshness`() {
        val now = System.currentTimeMillis()
        val fresh = AiEngine.importanceScore("رویداد", body, now, now)
        val stale = AiEngine.importanceScore("رویداد", body, now - 72L * 3_600_000, now)
        assertTrue(fresh >= stale)
    }

    @Test fun `keywords skip fa stopwords`() {
        val ks = AiEngine.keywords("این و که در از هوش مصنوعی هوش مصنوعی فارسی", 5)
        assertTrue("هوش" in ks || "مصنوعی" in ks)
        assertFalse("این" in ks)
        assertFalse("را" in ks)
    }

    @Test fun `related prefers keyword overlap`() {
        val a = post("p1", "قیمت طلا رکورد زد", "بازار طلا امروز جهش کرد و رکورد تاریخی شکست")
        val b = post("p2", "طلا گران شد", "فروشندگان طلا و بازار حاشیه‌ای با جهش قیمت مواجه‌اند")
        val c = post("p3", "مسابقه فوتبال", "تیم ملی امشب به میدان می‌رود و هواداران منتظرند")
        val rel = AiEngine.related(a, listOf(b, c))
        assertTrue(rel.firstOrNull()?.id == "p2")
    }

    @Test fun `digest finds hidden connection`() {
        val now = System.currentTimeMillis()
        val posts = listOf(
            post("1", "جهش طلا در بازار جهانی", "بازار طلا جهش کرد و سرمایه‌گذاران وارد شدند", now),
            post("2", "تحلیل بازار جهانی", "بازار جهانی با نوسان قیمت طلا همراه شد", now)
        )
        val d = AiEngine.dailyDigest(posts, now)
        assertEquals(2, d.totalAnalyzed)
        assertTrue(d.items.isNotEmpty())
    }

    @Test fun `importance thresholds map correctly`() {
        assertEquals(Importance.BREAKING, Importance.of(90))
        assertEquals(Importance.HIGH, Importance.of(70))
        assertEquals(Importance.NORMAL, Importance.of(10))
    }

    @Test fun `fa digits conversion`() {
        assertEquals("۱۲۳", AiEngine.run { "123".enDigitsToFa() })
        assertEquals("۵", AiEngine.run { 5.toFa() })
    }

    private fun post(id: String, title: String, body: String, at: Long = 0L) = Post(
        id = id, channelId = "c", channelName = "", channelVerified = true,
        title = title, body = body, imageRes = "", category = NewsCategory.ECONOMY,
        publishedAt = at, importance = 50, aiBullets = emptyList(),
        likeCount = 0, savesCount = 0, viewsCount = 0
    )
}
