# NewsFlow AI — Release build rules
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-keep class ir.newsflow.ai.** { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase { <init>(); }
-dontwarn org.slf4j.**
-dontwarn javax.annotation.**
# Firebase
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
# Kotlinx coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
